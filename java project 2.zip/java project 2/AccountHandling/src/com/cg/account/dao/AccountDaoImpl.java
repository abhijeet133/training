package com.cg.account.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.account.DbUtil.DbUtil;
import com.cg.account.bean.AccountBean;
import com.cg.account.exception.AccountException;


public class AccountDaoImpl implements IAccountDao {
	
	Connection conn=null;

	@Override
	public ArrayList<Integer> retrieveAccountId() throws AccountException {
		
		ArrayList<Integer> list=new ArrayList<Integer>();
		try {
			conn=DbUtil.getConnection();
		
		
		String sql="Select accountId from userAccount";
		
		
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(sql);
	
		
		while(rs.next())
		{
			int accountId=rs.getInt(1);		
			list.add(accountId);
		}
		
		
		}
		catch (SQLException e)
		{
			throw new AccountException("ERROR:" + e.getMessage());
			
		}
		
		return list;
		
	}

	@Override
	public int addAccountDetails(AccountBean bean) throws AccountException {
		
		int row=0;

		
		
		
		try{
			
			conn=DbUtil.getConnection();
			
			String insertQuery= "insert into userAccount1 values(seq_tId.nextval,?,?,?,?)";
			
			PreparedStatement ps= conn.prepareStatement(insertQuery);
			ps.setInt(1, bean.getAccountId());
			ps.setString(2, bean.getAccountType());
			ps.setInt(3,bean.getAmountWithdrawn());
			ps.setInt(4,bean.getBalance());
			
			row=ps.executeUpdate();
			
			
			
		
		}
		catch(SQLException e){
			
			throw new AccountException("ERROR:" + e.getMessage());
			
		}
		
		
		return row;
		
	}

}
