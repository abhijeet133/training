package com.cg.account.dao;

import java.util.ArrayList;

import com.cg.account.bean.AccountBean;
import com.cg.account.exception.AccountException;



public interface IAccountDao {
	
    public ArrayList<Integer> retrieveAccountId() throws AccountException;
	
	public int addAccountDetails(AccountBean bean) throws AccountException;

	

}
