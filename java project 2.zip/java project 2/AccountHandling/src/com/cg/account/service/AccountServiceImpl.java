package com.cg.account.service;

import java.util.ArrayList;

import com.cg.account.bean.AccountBean;
import com.cg.account.dao.AccountDaoImpl;
import com.cg.account.dao.IAccountDao;
import com.cg.account.exception.AccountException;


public class AccountServiceImpl implements IAccountService {

	IAccountDao dao=null;
	int totalBalance=1000;
	@Override
	public ArrayList<Integer> retrieveAccountId() throws AccountException {
		
		dao=new AccountDaoImpl();
		return dao.retrieveAccountId();
		
	}

	@Override
	public int addAccountDetails(AccountBean bean) throws AccountException {
		
		dao=new AccountDaoImpl();
		return dao.addAccountDetails(bean);
		
	}

	@Override
	public int balanceCal(int aWd) {
		
		return(totalBalance-aWd);
		
	}

	@Override
	public boolean isGreater(int withDrawl) {
		
		if(totalBalance<withDrawl)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	
	

	

}
