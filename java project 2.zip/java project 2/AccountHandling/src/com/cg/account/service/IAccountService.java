package com.cg.account.service;

import java.util.ArrayList;

import com.cg.account.bean.AccountBean;
import com.cg.account.exception.AccountException;

public interface IAccountService {
	
public ArrayList<Integer> retrieveAccountId() throws AccountException;
	
	public int addAccountDetails(AccountBean bean) throws AccountException;

	public int balanceCal(int aWd);
	
	
	public boolean isGreater(int withDrawl);

}
