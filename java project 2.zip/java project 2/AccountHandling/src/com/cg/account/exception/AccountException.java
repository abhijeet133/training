package com.cg.account.exception;



@SuppressWarnings("serial")
public class AccountException extends Exception{
	public AccountException(String message)
	{
		super(message);
	}
}
