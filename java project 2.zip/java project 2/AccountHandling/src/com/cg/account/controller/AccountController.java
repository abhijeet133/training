package com.cg.account.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.account.bean.AccountBean;
import com.cg.account.exception.AccountException;
import com.cg.account.service.AccountServiceImpl;
import com.cg.account.service.IAccountService;




@WebServlet("*.obj")
public class AccountController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
         AccountBean bean=new AccountBean();
		
		IAccountService service= new AccountServiceImpl();
		
		HttpSession session=request.getSession();
		
		String target=null;
		String path=request.getServletPath();
		switch(path)
		{
		case "/addAccount.obj" :
			
			
			ArrayList<Integer> list=null;
			
			try {
				list=service.retrieveAccountId();
			} catch (AccountException e) {
				
				session.setAttribute("error", e.getMessage());
				target="Error.jsp";
				
			}
			session.setAttribute("list", list);
			
			
			
			target="AccountDisplay.jsp";
			break;
			
		case "/details.obj" :
			
			int balance = 0;
			String accountId=request.getParameter("accountId");
			int aId=Integer.parseInt(accountId);
				
				
				String accountType=request.getParameter("txtAccountType");
				
				
				String amountWithdrawn=request.getParameter("amountWithdrawn");
				int aWd=Integer.parseInt(amountWithdrawn);
				
				
				try {
				 balance=service.balanceCal(aWd);
				 System.out.println(balance);
				 if(balance>0)
				 {
				
				bean.setAccountId(aId);
				bean.setAccountType(accountType);
				bean.setAmountWithdrawn(aWd);
				bean.setBalance(balance);
				
				
				int res=0;
				 
					res = service.addAccountDetails(bean);
					if(res>0)
					{
					session.setAttribute("aId", aId);
					session.setAttribute("accountType", accountType);
					
					session.setAttribute("aWd", aWd);
					session.setAttribute("balance", balance);
					
					target="Show.jsp";
					}
					
				 }
				 else
					{
						String m="Balance not entered correctly";
						session.setAttribute("error",m);
						target="Error.jsp";
					}
				} catch (AccountException e) {
					session.setAttribute("error", e.getMessage());
					target="Error.jsp";
				}
		

					
				
				
				break;
			
			
		
			

				
			
		
			
				
		}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
	}
		
		
	}


