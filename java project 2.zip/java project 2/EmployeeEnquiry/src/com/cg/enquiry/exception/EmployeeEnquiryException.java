package com.cg.enquiry.exception;

public class EmployeeEnquiryException extends Exception {

	public EmployeeEnquiryException(String msg)
	{
		super(msg);
	}
}
