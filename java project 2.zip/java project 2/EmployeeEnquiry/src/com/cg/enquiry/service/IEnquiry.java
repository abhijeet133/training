package com.cg.enquiry.service;

import java.util.ArrayList;

import com.cg.enquiry.DTO.Enquiry;
import com.cg.enquiry.exception.EmployeeEnquiryException;



public interface IEnquiry {
	
	public int addEnquiryDetails(Enquiry e) throws EmployeeEnquiryException;
	public ArrayList<Enquiry> retrieveDetails(int eid);
	//public boolean validateName(String name);

    public boolean validatePhoneNo(String phone);
	public boolean validateDomain(String Domain);
	//public boolean validateLocation(String Location);
}
