package com.cg.enquiry.service;


import java.util.ArrayList;
import java.util.regex.Pattern;




import com.cg.enquiry.DTO.Enquiry;
import com.cg.enquiry.dao.EnquiryDaoImpl;
import com.cg.enquiry.dao.IEnquiryDao;
import com.cg.enquiry.exception.EmployeeEnquiryException;


public class EnquiryImpl implements IEnquiry{
	IEnquiryDao dao=new EnquiryDaoImpl();

	@Override
	public int addEnquiryDetails(Enquiry e) throws EmployeeEnquiryException  {
		return dao. addEnquiryDetails(e);
	}

	@Override
	public ArrayList<Enquiry> retrieveDetails(int eid) {
		
		return dao.retrieveDetails(eid);
		
	}

/*public boolean validateName(String name)
	{
		String ptn="[A-Z]{1}[a-zA-Z]{2,19}";
		if(Pattern.matches(ptn, name))
		{
			return true;
		}
		else
		{
			System.out.println("Please enter the correct input name");
			return false;
		}
	}*/

/*public boolean validateEmail(String email)
{
	String emailPattern="^[?=.*A-Za-z0-9]+@[A_Za-z]+\\.[A-Za-z]{2,6}$";
	if(Pattern.matches(emailPattern,email))
	{
		return true;
	}
	else
	{
		System.out.println("Please enter the correct Email");
		return false;
	}
}*/
public boolean validatePhoneNo(String phone)
{
	String phonePattern="[0-9]{10}";
	if(Pattern.matches(phonePattern,phone))
	{
		return true;
	}
	else
	{
		System.out.println("Please enter the correct phone number");
		return false;
	}
}
public boolean validateDomain(String Domain)
{
	if(Domain.isEmpty() || Domain.equals(null))
	{
		System.out.println("Cannot be blank ");
		return false;
		
	}
	else
	{
		
		
		return true;
		
	}
		
	
}
/*public boolean validateLocation(String Location)
{
	if(Location !=null || !Location.isEmpty() )
	{
		return true;
	}
	else
	{
		System.out.println("Location cannot be blank ");
		return false;
	}
		
	
}*/




}
