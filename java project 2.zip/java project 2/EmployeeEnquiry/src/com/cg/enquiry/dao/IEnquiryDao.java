package com.cg.enquiry.dao;

import java.util.ArrayList;

import com.cg.enquiry.DTO.Enquiry;
import com.cg.enquiry.exception.EmployeeEnquiryException;




public interface IEnquiryDao {
	
	
								//dto name
	public int addEnquiryDetails(Enquiry e) throws EmployeeEnquiryException;
	
	

	public ArrayList<Enquiry> retrieveDetails(int eid);

}
