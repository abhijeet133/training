package com.cg.enquiry.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.enquiry.DTO.Enquiry;
import com.cg.enquiry.dbUtil.DbUtil;
import com.cg.enquiry.exception.EmployeeEnquiryException;



public class EnquiryDaoImpl implements IEnquiryDao{
	
	int result=0;
	int id=0;
	Connection conn=null;
	Logger logger=Logger.getRootLogger();
	public EnquiryDaoImpl()
	{
		PropertyConfigurator.configure("log4j.properties");
	}
	
	@Override
	public int addEnquiryDetails(Enquiry e) throws EmployeeEnquiryException
	{
		try {
			conn=DbUtil.getConnection();
	 
String insertQuery="Insert into enquiry values(enqryid_seq_id.nextval,?,?,?,?,?)";
		
		PreparedStatement ps=conn.prepareStatement(insertQuery,new String[] {"enquiryId"});
		ps.setString(1, e.getfName());
		ps.setString(2,e.getlName());
		ps.setString(3,e.getContactNo());
		ps.setString(4,e.getpLocation());
		ps.setString(5,e.getpDomain());
		
		
		
		result=ps.executeUpdate();
		
		ResultSet rs11 = ps.getGeneratedKeys();
		if (rs11.next()) 
		{
			
		   id = rs11.getInt(1);
		}
		
		logger.info("Executed succesfully");
		
		}
		catch (IOException e1) {
			
			logger.error("Exception occured"+e1.getMessage());
			
			e1.printStackTrace();
		}
catch (SQLException e1)
		{
	
	
	logger.error("Exception occured"+e1.getMessage());
	throw new EmployeeEnquiryException(e1.getMessage());
		}
		
		
	
	
	
		return id;
		
	}
	@Override
	public ArrayList<Enquiry> retrieveDetails(int eid)
	{
		
		
		ArrayList<Enquiry> list=new ArrayList<Enquiry>();
		try {
			conn=DbUtil.getConnection();
		
		
		String sql="Select * from enquiry where enquiryId=?";
		PreparedStatement pst=conn.prepareStatement(sql);
		pst.setInt(1, eid);
	
		ResultSet rs=pst.executeQuery();
		
		
	
		
		while(rs.next())
		{
			
			int enquiryId=rs.getInt(1);
			String fName=rs.getString(2);
			String lName=rs.getString(3);
			String contactNo=rs.getString(4);
			String pLocation=rs.getString(5);
			String pDomain=rs.getString(6);
			list.add(new Enquiry(enquiryId,fName,lName,contactNo,pLocation,pDomain));
			
		}
		logger.info("Executed succesfully");
		
		}
		catch (IOException | SQLException e) {
			
			logger.error("Exception occured"+e.getMessage());
			System.out.println(e.getMessage());
		}
		
		return list;
	}
		
	}



	
	

