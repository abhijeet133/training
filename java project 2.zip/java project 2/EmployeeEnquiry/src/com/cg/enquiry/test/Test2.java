package com.cg.enquiry.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.enquiry.DTO.Enquiry;
import com.cg.enquiry.dao.EnquiryDaoImpl;
import com.cg.enquiry.dao.IEnquiryDao;
import com.cg.enquiry.exception.EmployeeEnquiryException;


public class Test2 {

	static IEnquiryDao dao=null;
	static Enquiry bean=null;

	@BeforeClass
	public static void initilize() throws EmployeeEnquiryException {
		System.out.println("hi");
		dao=new EnquiryDaoImpl();
		bean=new Enquiry();
	}

	@Test
	public void test() {
		bean.setfName("jeet");
		bean.setlName("Last");
		bean.setContactNo("8444992099");
		bean.setpLocation("kolkata");
		bean.setpDomain("java");
	}
	@Test
	public void testAddDetails() throws EmployeeEnquiryException 
	{
		
		assertNotNull(dao.addEnquiryDetails(bean));
	}
	@Test
	public void getDetails()
	{
		assertNotNull(dao.retrieveDetails(0));
	}

}
