package com.cg.enquiry.UI;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.enquiry.DTO.Enquiry;
import com.cg.enquiry.exception.EmployeeEnquiryException;
import com.cg.enquiry.service.EnquiryImpl;
import com.cg.enquiry.service.IEnquiry;






public class EnquiryUI {
	static Scanner sc=new Scanner(System.in);
	static IEnquiry service= new EnquiryImpl();
	
	

	
	public static void main(String[] args) throws EmployeeEnquiryException 
	{
		System.out.println("Employee Enquiry");
		System.out.println("*************************************");
		while(true)
		{
			System.out.println("1.Enter Enquiry details");
			System.out.println("2.View Enquiry details on ID");
			System.out.println("3.Exit");
			
			System.out.println("*************************************");
			System.out.println("Enter your choice :- ");
			int choice=sc.nextInt();
			System.out.println("*************************************");
			switch(choice)
			{
			case 1:addEnquiryDetails();
			break;
			case 2:
			
				getEnquiryDetails();
					
			break;
			case 3: System.exit(0);
			break;
			
			}
			}
		
	}
	
	private static void addEnquiryDetails() throws EmployeeEnquiryException {
		IEnquiry service= new EnquiryImpl();
		
		try{
			sc.nextLine();
		
		System.out.println("Enter First name :- ");
		String fName=sc.nextLine();
		if(service.validateDomain(fName))
		{
		System.out.println("Enter Last name :- ");
		String lName=sc.nextLine();
		if(service.validateDomain(lName))
		{
		System.out.println("Enter Contact Number :- ");
		String contactNo=sc.nextLine();
		if(service.validatePhoneNo(contactNo))
		{
		System.out.println("Enter Preferred Domain :- ");
		String pDomain=sc.nextLine();
		if(service.validateDomain(pDomain))
		{
		System.out.println("Enter Preferred Location :- ");
		String pLocation=sc.nextLine();
		
		System.out.println("*************************************");
		if(service.validateDomain(pLocation))
		{
		
		Enquiry details=new Enquiry(fName,lName,contactNo,pDomain,pLocation);
		
		int res=service.addEnquiryDetails(details);

		if(res==0)
		{	
			System.out.println("value not added");
		}
		else
		{
			System.out.println("****************************************************");
			System.out.println("Thank You " +fName+" "+lName+ " . Your unique Id is " +res+ ". We will contact you shortly.");
			//System.out.println("value is added in database");
			System.out.println("**********************************************");
		}
		}}}}}}
		catch(EmployeeEnquiryException e){
			throw new EmployeeEnquiryException("Exception occured");
		}
	
	
}
	
	private static void getEnquiryDetails() 
	{
		System.out.println("*************************************");
		System.out.println("Enter Enquiry ID:- ");
		int eid=sc.nextInt();
		ArrayList<Enquiry> list=null;
		
		list=service.retrieveDetails(eid);
		if(list.isEmpty())
		{
			System.out.println("Sorry no details found");
			System.out.println("*************************************");
		}
		else
		{
		for(Enquiry m:list)
		{
			System.out.println("Enquiry Id - "+m.getEnquiryId());
			System.out.println("First Name - "+m.getfName());
			System.out.println("Last Name - "+m.getlName());
			System.out.println("Contact number - "+m.getContactNo());
			System.out.println("Domain - "+m.getpDomain());
			System.out.println("Preffered Location - "+ m.getpLocation());
			System.out.println("*************************************");
		}
		}
	}
	
}
