package com.cg.bank.service;

import java.util.ArrayList;

import com.cg.bank.bean.BankBean;


public interface IBankService {

	public int insertCustomer(BankBean bean);
	public ArrayList<BankBean> retrieveDetails();

}
