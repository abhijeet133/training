package com.cg.bank.service;

import java.util.ArrayList;

import com.cg.bank.bean.BankBean;
import com.cg.bank.dao.BankDaoImpl;
import com.cg.bank.dao.IBankDao;



public class BankServiceImpl implements IBankService {
		
	IBankDao dao=null;
	@Override
	public int insertCustomer(BankBean bean) {
		dao=new BankDaoImpl();
		return dao.insertCustomer(bean);
	}
	@Override
	public ArrayList<BankBean> retrieveDetails() {
		
		dao=new BankDaoImpl();
		return dao.retrieveDetails();
	}

}
