package com.cg.bank.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bank.bean.BankBean;
import com.cg.bank.service.BankServiceImpl;
import com.cg.bank.service.IBankService;




@WebServlet("*.obj")
public class HomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
   
	


	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		BankBean bean=new BankBean();
		
		IBankService service= new BankServiceImpl();
		
		HttpSession session=request.getSession();
		
		String target=null;
		String path=request.getServletPath();
		switch(path)
		{
		case "/insertNewCustomer.obj" :
			
			target="NewCustomer.html";
			break;
			
		case "/details.obj" :
			
			//String custId=request.getParameter("customerId");
		//	int cId=Integer.parseInt(custId);
			String customerName=request.getParameter("customerName");
			String phoneNo=request.getParameter("phoneNo");
			String password=request.getParameter("password");
		//	bean.setCustomerId(cId);
			bean.setCustomerName(customerName);
			bean.setPhoneNo(phoneNo);
			bean.setPassword(password);
			
			int res=service.insertCustomer(bean);
			
			if(res==0)
			{
				target="Error.html";
				
				
			}
			else
			{
				
				session.setAttribute("val", res);
				target="Success.jsp";
			}
			
			break;
			
		case "/pay.obj" :
			int i=1000;
			String bill=request.getParameter("amountToPay");
			Integer bill1=Integer.parseInt(bill);
			
			int remain=i-bill1;
			
			
			session.setAttribute("v", remain);
			
			target="pay.jsp";
			
			break;
			
		case "/retrieveCustomerDetails.obj" :
			

			ArrayList<BankBean> list=null;
			
			list=service.retrieveDetails();
			
			
			session.setAttribute("list", list);
			
			
			 target="retrieve.jsp";
			
				
		}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
	}

}
