package com.cg.bank.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.bank.DbUtil.DbUtil;
import com.cg.bank.bean.BankBean;



public class BankDaoImpl implements IBankDao {
	Connection conn=null;
	@Override
	public int insertCustomer(BankBean bean) {
		
		int row=0;

		int id=0;
			
			
			try{
				
				conn=DbUtil.getConnection();
				
				String insertQuery= "insert into bank values(seq_custId.nextval,?,?,?)";
				
				PreparedStatement ps= conn.prepareStatement(insertQuery,new String[]{"customerId"});
				ps.setString(1, bean.getCustomerName());
				ps.setString(2, bean.getPhoneNo());
				ps.setString(3,bean.getPassword());
				
				row=ps.executeUpdate();
				
				ResultSet rs=ps.getGeneratedKeys();
				if(rs.next())
				{
					id=rs.getInt(1);
				}
			
			}
			catch(SQLException e){
				
				System.out.println("e.getMessage()");
				
			}
			
			
			return id;
			
			}

	@Override
	public ArrayList<BankBean> retrieveDetails() {
		
		
			ArrayList<BankBean> list=new ArrayList<BankBean>();
			try {
				conn=DbUtil.getConnection();
			
			
			String sql="Select * from bank";
			
			
			Statement st=conn.createStatement();
			ResultSet rs=st.executeQuery(sql);
		
			
			while(rs.next())
			{
				int custId=rs.getInt(1);
				String custName=rs.getString(2);
				String phoneNo=rs.getString(3);
				String pass=rs.getString(4);
				
				list.add(new BankBean(custId,custName,phoneNo,pass));
				System.out.println(list);
				
			}
			
			
			}
			catch (SQLException e)
			{
				
				System.out.println(e.getMessage());
			}
			
			return list;
	}
		
	}


