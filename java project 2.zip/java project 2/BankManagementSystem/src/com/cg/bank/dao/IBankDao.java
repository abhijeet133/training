package com.cg.bank.dao;

import java.util.ArrayList;

import com.cg.bank.bean.BankBean;

public interface IBankDao {

	public int insertCustomer(BankBean bean);
	public ArrayList<BankBean> retrieveDetails();

}
