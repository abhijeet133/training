package com.cg.customer.client;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.cg.customer.bean.CustomerBean;
import com.cg.customer.service.CustomerServiceImpl;
import com.cg.customer.service.ICustomerService;



public class Client {
	static CustomerBean details=null;
	
	static Scanner sc=new Scanner(System.in);
	
	static ICustomerService service= new CustomerServiceImpl();
	
	public static void main(String[] args) {
		
		
		
		
		
		System.out.println("*******************");
		while(true)
		{
			System.out.println("1.Retrive");
			System.out.println("2.Insert");
			System.out.println("3.retrive details by id");
			System.out.println("4.retrive by name");
			System.out.println("5.Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:retrieveDetails();
				
			break;
			case 2:insert();
			break;
			case 3:getDetailsById(); 
				
			break;
			
			case 4:getByName();
			break;
			
			case 5:System.exit(0);
			break;
			
			}
			
		}
	}
	
	
		
		private static void getByName() {
			
			System.out.println("Enter name:-");
			String name=sc.next();
			System.out.println("Deatails by name:- "+service.getByName(name));
		
			
		
	}



		private static void getDetailsById() {
			
			
			System.out.println("Enter the id");
			int id=sc.nextInt();
			
			System.out.println("details by id:- "+service.getdeatilsId(id));
			
			
			
			
			
		
		
	}


		private static void insert() {
			/* System.out.println("Enter id:");
			
			int id=sc.nextInt();*/
			System.out.println("Enter name:");
			String name=sc.next();
			
		System.out.println("Enter dob:");
			String date = sc.next();

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
		Date date2=null;
		
		    try {
				date2 = dateFormat.parse(date);
				
			} catch (ParseException e) {
				
				e.printStackTrace();
			}
		
		    System.out.println("Enter mobile");
		    Long mob=sc.nextLong();
		    
		    
		    
		    details=new CustomerBean(name,date2,mob);
		    
		    service.insert(details);
		    
		    System.out.println("Done");
		
	}


		private static void retrieveDetails() {
			ArrayList<CustomerBean> list=null;
			
			 list=service.retrieveDetails();
			for(CustomerBean bean: list )
			{
				System.out.println("Cid"+bean.getCustomerId());
				System.out.println("Cname"+bean.getCustomerName());
				System.out.println("dob"+bean.getDateOfBirth());
				System.out.println("Mobile"+bean.getMobileNumber());
			}
			
		
	}


		
		
	    
	   
	    
	    
		
	}


