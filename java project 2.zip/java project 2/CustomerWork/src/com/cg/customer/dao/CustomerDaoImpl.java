package com.cg.customer.dao;

import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cd.customer.JpaUtil.JPAUtil;
import com.cg.customer.bean.CustomerBean;






public class CustomerDaoImpl implements ICustomerDao{
	
	private EntityManager entityManager=JPAUtil.getEntityManager();
	
		
	
	

	@Override
	public ArrayList<CustomerBean> retrieveDetails() {
		
		
		
		
		
		//String qStr = "SELECT customer FROM CustomerBean customer";
		
		
		//TypedQuery<CustomerBean> query = entityManager.createQuery(qStr,CustomerBean.class);
		Query query = entityManager.createNamedQuery("getCustomer");
		
		
		@SuppressWarnings("unchecked")
		ArrayList<CustomerBean> list = (ArrayList<CustomerBean>) query.getResultList();

		return list;
		
		
		
		
	
		
		
		
	}

	

	@Override
	public void insert(CustomerBean bean) {
		entityManager.persist(bean);
	}



	@Override
	public void createTransaction() {
		entityManager.getTransaction().begin();
		
	}



	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}



	@Override
	public CustomerBean getdeatilsId(int id) {
		CustomerBean bean = entityManager.find(CustomerBean.class, id);
		return bean;
		
	}



	@Override
	public List<CustomerBean> getByName(String name) {
		String qStr = "SELECT customer FROM CustomerBean customer WHERE customer.customerName=:pCustName";
		TypedQuery<CustomerBean> query = entityManager.createQuery(qStr, CustomerBean.class);
		query.setParameter("pCustName",name);
		
		return query.getResultList();
		
	}

}
