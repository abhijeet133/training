package com.cg.customer.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.customer.bean.CustomerBean;






public interface ICustomerDao {
	
//	public abstract Book getBookById(int id);
	public ArrayList<CustomerBean> retrieveDetails();
	
	public abstract void insert(CustomerBean bean);

	public void createTransaction();

	public void commitTransaction();
	
	public abstract CustomerBean getdeatilsId(int id);
	
	public abstract List<CustomerBean> getByName(String name);
	
	

}
