package com.cg.customer.service;

import java.util.ArrayList;



import java.util.List;

import com.cg.customer.bean.CustomerBean;
import com.cg.customer.dao.CustomerDaoImpl;
import com.cg.customer.dao.ICustomerDao;


public class CustomerServiceImpl implements ICustomerService{
	
	private ICustomerDao dao= new CustomerDaoImpl();

	@Override
	public ArrayList<CustomerBean> retrieveDetails() {
		
		return dao.retrieveDetails();
		
	}

	@Override
	public void insert(CustomerBean bean) {

		dao.createTransaction();
		dao.insert(bean);
		dao.commitTransaction();
	}

	@Override
	public CustomerBean getdeatilsId(int id) {
		
		return dao.getdeatilsId(id);
		
	}

	@Override
	public List<CustomerBean> getByName(String name) {
		return dao.getByName(name);
	}

}
