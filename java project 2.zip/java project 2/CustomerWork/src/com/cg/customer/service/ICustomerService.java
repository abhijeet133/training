package com.cg.customer.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.customer.bean.CustomerBean;

public interface ICustomerService {
	
	public ArrayList<CustomerBean> retrieveDetails();
	
	public abstract void insert(CustomerBean bean);
	
	public abstract CustomerBean getdeatilsId(int id);
	
	
	
	public abstract List<CustomerBean> getByName(String name);

}
