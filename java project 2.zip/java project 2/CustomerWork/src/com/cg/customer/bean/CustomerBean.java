package com.cg.customer.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: CustomerBean
 *
 */
@Entity
@Table(name = "customer")

@NamedQueries(@NamedQuery(name="getCustomer",query="select cust from CustomerBean cust"))

public class CustomerBean implements Serializable {
	
	

	
	private static final long serialVersionUID = 1L;

	@Id
	
	@SequenceGenerator(name = "seqid-gen", sequenceName = "RTDS_ADSINPUT_SEQ", allocationSize = 1, initialValue = 0)
	@Column(name="custId")
	private int customerId;
	@Column(name="custName")
	private String customerName;
	@Column(name="dob")
	private Date dateOfBirth;
	@Column(name="mobile")
	private Long mobileNumber;
	
	
	public CustomerBean()
	{
		
	}


	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public Date getDateOfBirth() {
		return dateOfBirth;
	}


	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	public Long getMobileNumber() {
		return mobileNumber;
	}


	public void setMobileNumber(Long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	@Override
	public String toString() {
		return "CustomerBean [customerId=" + customerId + ", customerName="
				+ customerName + ", dateOfBirth=" + dateOfBirth
				+ ", mobileNumber=" + mobileNumber + "]";
	}


	public CustomerBean(String customerName, Date dateOfBirth, Long mobileNumber) {
		super();
		this.customerName = customerName;
		this.dateOfBirth = dateOfBirth;
		this.mobileNumber = mobileNumber;
	}
	
	
	
	
	
	





	
	
	
   
}
