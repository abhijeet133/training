import java.util.Arrays;


public class forEachloop {

	public static void main(String[] args)
	{
		int a[]={10,4,2,1};
		Arrays.sort(a);
		for(int out:a)
		{
			System.out.println(out);
		}

	}

}
