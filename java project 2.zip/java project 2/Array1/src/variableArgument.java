
public class variableArgument {
	
	public static void fun(int ...a)
	{
		for(int out:a)
		{
			System.out.println(out);
		}
	}

	public static void main(String[] args)
	{
		fun(10,20);
		fun(10,20,30,40);

	}

}
