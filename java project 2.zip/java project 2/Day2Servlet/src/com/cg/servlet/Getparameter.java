package com.cg.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Getparameter
 */
@WebServlet("/Getparameter")
public class Getparameter extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("uname");
		String pass=request.getParameter("pwd");
		String phone=request.getParameter("phoneNo");
		
		
		ServletContext context=getServletContext();
		context.setAttribute("username", name);
		context.setAttribute("password", pass);
		context.setAttribute("pnumber", phone);
	//	RequestDispatcher rd=request.getRequestDispatcher("SecondServlet");
	//	RequestDispatcher rd=getServletContext().getRequestDispatcher("/SecondServlet");
	//	rd.forward(request, response);
		response.sendRedirect("SecondServlet");
		PrintWriter out= response.getWriter();
		out.print("<html><body>");
		out.print("welcome "+name+ "</br>");
		out.print("Password "+pass+"</br>");
		out.print("Phone "+phone);
		out.print("</body></html>");
	}

	

}
