package abstract1;

import java.util.ArrayList;

public class listA {

	public static void main(String args[]) {
		
		
		CustomerBean bean = new CustomerBean();
		ArrayList<CustomerBean> list = new ArrayList<CustomerBean>();
		
		bean.setAccid(1);
		bean.setAccid(2);
		
		list.add(bean);
		list.add(bean);
		
		int a=1;
		
		for(CustomerBean bean1 : list) { 
			
			if(bean1.getAccid()==a){
				System.out.println("found");
			}
			else{
				System.out.println("Not");
			}
			   
		}
		
	/*	System.out.println(list);
		
		if (list.contains(a)) {
		    System.out.println("Account found");
		} else {
		    System.out.println("Account not found");
		    
		}*/
		
		
		/*if (((CustomerBean) list).getAccid().equals(a)) {
		    System.out.println("Account found");
		} else {
		    System.out.println("Account not found");
		    System.exit(0);
		}*/
		
		
		

	}

}
