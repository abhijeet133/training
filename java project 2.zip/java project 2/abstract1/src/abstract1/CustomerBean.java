package abstract1;

public class CustomerBean {
	
	private int accid;
	
	
	public CustomerBean(){
		
	}

	
	
	@Override
	public String toString() {
		return "CustomerBean [accid=" + accid + "]";
	}



	public int getAccid() {
		return accid;
	}



	public void setAccid(int accid) {
		this.accid = accid;
	}



	public CustomerBean(int accid) {
		super();
		this.accid = accid;
	}
	
	
}
