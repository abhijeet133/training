package abstract1;

public class AbstractClass
{

	public static void main(String[] args)
	{
		Shape s= new Rectangle();
		s.display();
		s.call();
		s.show();
		
	}
	
}


abstract class Shape
{
	abstract void display();
	abstract void show();
	void call()
	{
		
		System.out.println("concreate method/non abstarct method");
	}
}

class Rectangle extends Shape
{
	void display()
	{
		
		System.out.println("This is Rectangle");
	}
	
	void show()
	{
		
		System.out.println("This is show");
	}
}