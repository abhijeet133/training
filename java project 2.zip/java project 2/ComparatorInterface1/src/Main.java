import java.util.ArrayList;
import java.util.Collections;


public class Main {

	public static void main(String[] args) {
		
		ArrayList<Employee> al=new ArrayList<Employee>();
		al.add(new Employee(101,"kavin",25000));
		al.add(new Employee(102,"vin",10000));
		al.add(new Employee(103,"ka",2000));
		al.add(new Employee(104,"avin",5000));
		Collections.sort(al);
		for(Employee e:al)
		{
			System.out.println(e);
		}
		
	}

}
