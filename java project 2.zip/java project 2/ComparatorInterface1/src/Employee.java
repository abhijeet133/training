
class Employee implements Comparable<Employee> {
int eId;
String eName;
int salary;
public Employee(int eId, String eName, int salary) {
	super();
	this.eId = eId;
	this.eName = eName;
	this.salary = salary;
}
@Override
public int compareTo(Employee e) {
	// TODO Auto-generated method stub
	if(salary==e.salary)
	{
		return 0;
	}
	else if(salary>e.salary)
	{
		return 1;
	}
	else
		return -1;
	
}
@Override
public String toString() {
	return "Employee [eId=" + eId + ", eName=" + eName + ", salary=" + salary
			+ "]";
}

	
	

}
