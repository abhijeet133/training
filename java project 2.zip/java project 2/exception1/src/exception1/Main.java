package exception1;

public class Main {
	
	

	public static void main(String[] args) {
		
		
		
		
		String s=null;
		System.out.println(s.length());
		try{
			
			int a[]= new int[5];
			a[7]=60;
		}
	/*	catch(ArithmeticException e)
		{
			System.out.println("Invalid input");
		}*/
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Array out of bound");
		}
		catch(Exception e)
		{
			System.out.println(e);
			System.out.println("age error");
		}
		finally{
			
			System.exit(0);  //to stop execution of finally block
			
			System.out.println("Always execute");
		}
	}

}
