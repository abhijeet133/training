package bank;

import java.util.Scanner;
import java.util.regex.Pattern;

public class Bank {

	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Bank application Details");
		System.out.println("--------------------------");
		System.out.println("Enter the choice- ");
		System.out.println("\n");
		System.out.println("1.Bank Details");
		System.out.println("2.Account details");
		System.out.println("3.Exit");
		int choice=sc.nextInt();
		
		switch(choice)
		{
		case 1:
				
				System.out.println("Enter bank name:-  ");
				String bankName=sc.next();
				String pattern="[a-z]{2,}";
				boolean b=Pattern.matches(pattern, bankName);
					if(b==false)
						{
							System.out.println("Invalid account number");
							break;
						}
					else
				System.out.println("Enter IFSC Code:-  ");
				String ifsc=sc.next();
				System.out.println("Enter branch location:- ");
				String branchLocation=sc.next();
				
				System.out.println("Bank name is:- " +bankName+"\n"+"IFSC code is:- " +ifsc+"\n"+"Branch Location is :- "+branchLocation);
				break;
				
		case 2:
				System.out.println("Enter account number:- ");
				int accNo=sc.nextInt();
				System.out.println("Enter account holder name:- ");
				String holderName=sc.next();
				System.out.println("Enter account type:- ");
				String accountType=sc.next();
				System.out.println("Account number:- "+accNo+"\n"+"Account holder name:- "+holderName+"\n"+"Account type:- "+accountType);
				break;
				
		case 3:
				System.out.println("Exit");
				
				break;
		default:
				System.out.println("Please enter correct choice");
				
		}

	}

}
