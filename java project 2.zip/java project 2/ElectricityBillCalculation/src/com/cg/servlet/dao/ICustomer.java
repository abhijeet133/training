package com.cg.servlet.dao;

import com.cg.servlet.bean.CustomerBean;

public interface ICustomer {
	
	public int addDetails(CustomerBean bean);

}
