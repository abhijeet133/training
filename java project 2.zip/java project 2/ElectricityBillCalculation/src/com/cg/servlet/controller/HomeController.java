package com.cg.servlet.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.servlet.bean.CustomerBean;
import com.cg.servlet.service.CustomerServiceImpl;
import com.cg.servlet.service.ICustomerService;


@WebServlet("*.obj")
public class HomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
		
		CustomerBean bean=new CustomerBean();
		
		ICustomerService service= new CustomerServiceImpl();
		
		String target=null;
		String path=request.getServletPath();
		switch(path)
		{
		case "/customer.obj" :
			
			String consumerNo=request.getParameter("consumerNo");
			int conNo=Integer.parseInt(consumerNo);
			String consumerName=request.getParameter("consumerName");
			String email=request.getParameter("email");
			String phoneNo=request.getParameter("phoneNo");
			bean.setConsumerNo(conNo);
			bean.setCustomerName(consumerName);
			bean.setEmailId(email);
			bean.setPhoneNo(phoneNo);
			
			int res=service.addDetails(bean);
			if(res==1)
			{
				target="Success.html";
			}
			else
			{
				target="Error.html";
				
			}
			
			break;
			
			
				
		}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
		
		
	}

	
	

}
