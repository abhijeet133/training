package com.cg.servlet.service;


import com.cg.servlet.bean.CustomerBean;
import com.cg.servlet.dao.CustomerImpl;
import com.cg.servlet.dao.ICustomer;

public class CustomerServiceImpl implements ICustomerService{
	ICustomer dao=null;

	public int addDetails(CustomerBean bean) {
		
		
		dao=new CustomerImpl();
		return dao.addDetails(bean);
	}

	
	
	

}
