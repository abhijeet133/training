package com.cg.servlet.service;

import com.cg.servlet.bean.CustomerBean;

public interface ICustomerService{
	
	public int addDetails(CustomerBean bean);

}
