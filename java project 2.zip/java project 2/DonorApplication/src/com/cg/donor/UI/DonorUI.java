package com.cg.donor.UI;

import java.util.Scanner;

import com.cg.donor.DTO.DonorEntry;
import com.cg.donor.service.DonorServiceImpl;
import com.cg.donor.service.IDonorService;





public class DonorUI {
	static DonorEntry details=null;
	static Scanner sc=new Scanner(System.in);
	
	
	public static void main(String[] args) {
		
		DonorUI d =  new DonorUI();
		
		
		System.out.println("*******************");
		while(true)
		{
			System.out.println("1.Enter donor details");
			
			System.out.println("2.Exit");
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:addDonorDetails();
			break;
			
			case 2: System.exit(0);
			break;
			
			}
			
		}
		
		
	}


	private static void addDonorDetails() {
		IDonorService service= new DonorServiceImpl();
		
		
		System.out.println("Enter Donor name");
		String donorName=sc.next();
		System.out.println("Enter phone number");
		String phoneNo=sc.next();
		System.out.println("Enter Address");
		String address=sc.next();
		System.out.println("Enter Donation Amount");
		int donationAmount=sc.nextInt();
		
		details=new DonorEntry(donorName,phoneNo,address,donationAmount);
		
		int res=service.addDonorDetails(details);

		if(res==1)
		{		System.out.println(res+" inserted");
			System.out.println("value is added in database");
		}
		else
		{
			System.out.println("value not added");
		}
	
		
	}
	

}
