package com.cg.donor.exception;

public class DonorApplicationException {

}
