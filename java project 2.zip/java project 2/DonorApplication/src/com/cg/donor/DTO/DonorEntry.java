package com.cg.donor.DTO;

import java.time.LocalDate;

public class DonorEntry {
	private String donorId;
	private String donorName;
	private String phoneNo;
	private String address;
	private int donationAmount;
	private LocalDate donationDate;
	public String getDonorId() {
		return donorId;
	}
	public void setDonorId(String donorId) {
		this.donorId = donorId;
	}
	public String getDonorName() {
		return donorName;
	}
	public void setDonorName(String donorName) {
		this.donorName = donorName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getDonationAmount() {
		return donationAmount;
	}
	public void setDonationAmount(int donationAmount) {
		this.donationAmount = donationAmount;
	}
	public LocalDate getDonationDate() {
		return donationDate;
	}
	public void setDonationDate(LocalDate donationDate) {
		this.donationDate = donationDate;
	}
	
	
	
	
	
	public DonorEntry(String donorName, String phoneNo, String address,
			int donationAmount) {
		super();
		this.donorName = donorName;
		this.phoneNo = phoneNo;
		this.address = address;
		this.donationAmount = donationAmount;
	}
	public DonorEntry()
	{
		
	}
	@Override
	public String toString() {
		return "DonorEntry [donorId=" + donorId + ", donorName=" + donorName
				+ ", phoneNo=" + phoneNo + ", address=" + address
				+ ", donationAmount=" + donationAmount + ", donationDate="
				+ donationDate + "]";
	}
	

}
