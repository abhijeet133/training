package com.cg.donor.service;

import com.cg.donor.DTO.DonorEntry;
import com.cg.donor.dao.DonorDaoImpl;
import com.cg.donor.dao.IDonorDao;




public class DonorServiceImpl implements IDonorService{
	
	IDonorDao dao=new DonorDaoImpl();

	@Override
	public int addDonorDetails(DonorEntry d) {
		
		
		return dao.addDonorDetails(d);
	}

}
