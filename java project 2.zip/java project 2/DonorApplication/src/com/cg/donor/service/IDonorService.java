package com.cg.donor.service;

import com.cg.donor.DTO.DonorEntry;

public interface IDonorService {
	public int addDonorDetails(DonorEntry d);

}
