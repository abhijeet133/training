package com.cg.donor.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.cg.donor.DTO.DonorEntry;
import com.cg.donor.dbUtil.DbUtil;


public class DonorDaoImpl implements IDonorDao {
	Connection conn=null;
	int result=0;
	@Override
	public int addDonorDetails(DonorEntry d) {
		
		try {
			conn=DbUtil.getConnection();
		
		String insertQuery="Insert into donor values(donor_seq_id.nextval,?,?,?,?,SYSDATE)";
		
		PreparedStatement ps=conn.prepareStatement(insertQuery);
		ps.setString(1, d.getDonorName());
		ps.setString(2,d.getPhoneNo());
		ps.setString(3,d.getAddress());

		ps.setInt(4,d.getDonationAmount());
		result=ps.executeUpdate();
				
			System.out.println(result);
			
		}
		 catch (IOException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return result;
	}

}
