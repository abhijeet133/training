package com.cg.donor.dao;

import com.cg.donor.DTO.DonorEntry;



public interface IDonorDao {

	public int addDonorDetails(DonorEntry d);
}
