package com.cg.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.exception.CustomerException;
import com.cg.model.CustomerBean;

public interface ICustomerDao {

	public abstract void add(CustomerBean bean);
	
	public abstract CustomerBean getById(int complaintId);



}
