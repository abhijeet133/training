package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.exception.CustomerException;
import com.cg.model.CustomerBean;



public interface ICustomerService {
	
	public abstract void add(CustomerBean bean) throws CustomerException;
	public abstract CustomerBean getById(int complaintId);

	
}
