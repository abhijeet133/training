//2.1 Write a java program to print person details in the format as shown below:

package assingment;
import java.util.Scanner;

public class personDetails {

	public static void main(String[] args)
	{
		System.out.println("Person details:");
		System.out.println("_________________");
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("First Name:");
		 String firstName=sc.next();
		 
		 System.out.println("Last Name:");
		 String lastName=sc.next();
		 
		 System.out.println("Gender:");
		 char gender=sc.next().charAt(0);
		 
		 System.out.println("Age:");
		 int age=sc.nextInt();
		
		 System.out.println("Weight:");
		 Float wt=sc.nextFloat();
		 
		 System.out.println("Person details:"+"\n");
		 System.out.println("_________________"+"\n"+"\n");
		 System.out.println("First Name:"+firstName+"\n");
		 System.out.println("Last Name:"+lastName+"\n");
		 System.out.println("Gender:"+gender+"\n");
		 System.out.println("Age:"+age+"\n");
		 System.out.println("Weight:"+wt+"\n");
		 
	}

}
