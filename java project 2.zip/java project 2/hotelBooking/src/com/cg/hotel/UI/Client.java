package com.cg.hotel.UI;

import java.util.ArrayList;
import java.util.Scanner;



import com.cg.hotel.DTO.RoomRegistration;
import com.cg.hotel.exception.HotelApplicationException;
import com.cg.hotel.service.HotelServiceImpl;
import com.cg.hotel.service.IHotelService;






public class Client {
	
	static Scanner sc=new Scanner(System.in);
	
	
	public static void main(String[] args) throws HotelApplicationException  {
		
		
		System.out.println("Hotel booking");
		System.out.println("*******************");
		while(true)
		{
			System.out.println("1.Booking Room");
			System.out.println("2.Exit");			
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1: hotelRegistration();
			break;

			case 2: 
				System.out.println("Thank you for visiting us!!!!!");	
				System.exit(0);
			break;
			
			}
			
		}
		
	}


	private static void hotelRegistration() throws HotelApplicationException {
		try{
		IHotelService service= new HotelServiceImpl();
		
		ArrayList<Integer> list=null;
		int l=0;
		
		list=service.retrieveDetails();
	//	for(HotelOwner m:list)
		{
			
			System.out.println("Existing hotel owner IDs are:-"+list);
				
		}
		
		
		System.out.println("Please enter your hotel owner id from above list:- ");
		int hotelOwnerId=sc.nextInt();
		
		if(service.validateHotelId(hotelOwnerId,list))
			{
		
		System.out.println("Select your room type(1--Ac,2-2NON-AC):- ");
		int roomType=sc.nextInt();
		
		System.out.println("Enter room area in sq ft:- ");
		int roomArea=sc.nextInt();
		
		System.out.println("Enter desired rent amount:- ");
		int dRentAmount=sc.nextInt();
		
		System.out.println("Enter desired paid amount:- ");
		int dPaidAmount=sc.nextInt();
		
		if(service.validateAmount(dRentAmount,dPaidAmount))
		{
		
		RoomRegistration details=new RoomRegistration(hotelOwnerId,roomType,roomArea,dRentAmount,dPaidAmount);
		
		int res=service.hotelRegistration(details);

		if(res==0)
		{	
			System.out.println("value not added");
		}
		else
		{
			System.out.println("****************************************************");
			System.out.println("Room successfully registered. Room no:<"+res+">");
			//System.out.println("value is added in database");
			System.out.println("**********************************************");
		}
		}
		else
		{
			System.out.println("Paid amount must be greater then rent amount");
		}
		}
		else
		{
			System.out.println("hotel owner  id does not exists");
		}
		
		}
		catch(HotelApplicationException e)
		{
			throw new HotelApplicationException("Exception occured");
		}
		
	}
}


