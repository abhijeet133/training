package com.cg.hotel.dao;

import java.util.ArrayList;



import com.cg.hotel.DTO.RoomRegistration;
import com.cg.hotel.exception.HotelApplicationException;




public interface IHotelDAO {
	
	public int hotelRegistration(RoomRegistration r) throws HotelApplicationException;
	
	public ArrayList<Integer> retrieveDetails() throws HotelApplicationException;
	

}
