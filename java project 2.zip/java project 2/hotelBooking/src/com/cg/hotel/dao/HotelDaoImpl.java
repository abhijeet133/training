package com.cg.hotel.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;



import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.hotel.DTO.RoomRegistration;
import com.cg.hotel.dbUtil.DbUtil;
import com.cg.hotel.exception.HotelApplicationException;



public class HotelDaoImpl implements IHotelDAO{
	
	int result=0;
	Connection conn=null;
	int id=0;
	
	Logger logger=Logger.getRootLogger();
	public HotelDaoImpl()
	{
		PropertyConfigurator.configure("log4j.properties");
	}

	@Override
	public int hotelRegistration(RoomRegistration r) throws HotelApplicationException
	{
		try{
		
			conn=DbUtil.getConnection();
		
		 
		String insertQuery="Insert into room_registration values(room_SEQ1.nextval,?,?,?,?,?)";
				
				PreparedStatement ps=conn.prepareStatement(insertQuery,new String[] {"roomNO"});
				ps.setInt(1, r.getHotelId());
				ps.setInt(2,r.getRoomType());
				ps.setInt(3,r.getRoomArea());
				ps.setInt(4,r.getRentAmount());
				ps.setInt(5,r.getPaidAmount());
				
				
				
				result=ps.executeUpdate();
				
				ResultSet rs11 = ps.getGeneratedKeys();
				if (rs11.next()) 
				{
					
				   id = rs11.getInt(1);
				}
				
				logger.info("Executed succesfully");
		}
		
		catch (IOException | SQLException e) {
			logger.error("Exception occured"+e.getMessage());
			
			e.printStackTrace();
			throw new HotelApplicationException(e.getMessage());
		}
		
		return id;
	}

	@Override
	public ArrayList<Integer> retrieveDetails() throws HotelApplicationException {
		
		ArrayList<Integer> list=new ArrayList<Integer>();
		
			try {
				conn=DbUtil.getConnection();
			
		
		
		String sql="Select * from hotelOwners";
		
		
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(sql);
	
		
		while(rs.next())
		{
			
			int hotelId=rs.getInt(1);
		//	String name=rs.getString(2);
		//	String mobile=rs.getString(3);
			
			list.add(new Integer(hotelId));
			
			
			logger.info("Executed succesfully");
			
		}
		
			}
			 catch (IOException | SQLException e) {
				 logger.error("Exception occured"+e.getMessage());
					e.printStackTrace();
					throw new HotelApplicationException(e.getMessage());
				}
			return list;
				}
	}
		
		


