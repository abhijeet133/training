package com.cg.hotel.test;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.hotel.DTO.RoomRegistration;
import com.cg.hotel.dao.HotelDaoImpl;
import com.cg.hotel.dao.IHotelDAO;
import com.cg.hotel.exception.HotelApplicationException;



public class Test1 {

	static IHotelDAO dao=null;
	static RoomRegistration bean=null;

	@BeforeClass
	public static void initilize() throws HotelApplicationException {
		System.out.println("hi");
		dao=new HotelDaoImpl();
		bean=new RoomRegistration();
	}
	
	@Test
	public void test()
	{
		bean.setRoomNo(1001);
		bean.setHotelId(1);
		bean.setPaidAmount(200);
		bean.setRentAmount(500);
		bean.setRoomArea(100);
		bean.setRoomType(2);

	}

	@Test
	public void testAddDetails()
	{
		
		try {
			assertNotNull(dao.hotelRegistration(bean));
		} catch (HotelApplicationException e) {
			System.out.println("Test");
			
			//e.printStackTrace();
		}
	}
	@Test
	public void getDetails()
	{
		try {
			assertNotNull(dao.retrieveDetails());
		} catch (HotelApplicationException e) {
			System.out.println("Test");
		//	e.printStackTrace();
		}
	}

}
