package com.cg.hotel.exception;

public class HotelApplicationException extends Exception{
	
	public HotelApplicationException(String msg)
	{
		super(msg);
	}

}
