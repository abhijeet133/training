package com.cg.hotel.service;

import java.util.ArrayList;



import com.cg.hotel.DTO.RoomRegistration;
import com.cg.hotel.exception.HotelApplicationException;

public interface IHotelService{
	
	
	public int hotelRegistration(RoomRegistration r) throws HotelApplicationException;
	public ArrayList<Integer> retrieveDetails() throws HotelApplicationException;
	public boolean validateHotelId(int hotelId, ArrayList<Integer> list);
	public boolean validateAmount(int rentAmount,int paidAmount);

}
