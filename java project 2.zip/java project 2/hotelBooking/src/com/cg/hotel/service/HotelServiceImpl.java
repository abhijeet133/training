package com.cg.hotel.service;

import java.util.ArrayList;
import com.cg.hotel.DTO.RoomRegistration;
import com.cg.hotel.dao.HotelDaoImpl;
import com.cg.hotel.dao.IHotelDAO;
import com.cg.hotel.exception.HotelApplicationException;


public class HotelServiceImpl implements IHotelService {

	IHotelDAO dao=null;
	
	@Override
	public int hotelRegistration(RoomRegistration r) throws HotelApplicationException {
		dao=new HotelDaoImpl();
	
		return dao.hotelRegistration(r);
		
	}

	@Override
	public ArrayList<Integer> retrieveDetails() throws HotelApplicationException {
		try {
			dao=new HotelDaoImpl();
		} 
		catch (Exception e) {
			
			e.printStackTrace();
		}
		return dao.retrieveDetails();
		
	}

	@Override
	public boolean validateHotelId(int hotelId,ArrayList<Integer> list) {
		
		boolean flag=false;
		for(Integer out:list)
		{
			if(out == hotelId)
			{
				flag=true;
				break;
			}
		}
		return flag;
	}

	@Override
	public boolean validateAmount(int rentAmount, int paidAmount) 
	{
		if(paidAmount>rentAmount)
		{
			return true;
		}
		return false;
	}

	



	
}
