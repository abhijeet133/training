import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;


public class Arraylist1 {

	public static void main(String[] args) 
	{
		ArrayList<Integer> al= new ArrayList<Integer>();
		al.add(5);
		al.add(3);
		al.add(2);
		al.add(6);
		al.add(9);
		
		System.out.println(al);
	//	Collections.sort(al);
	//	System.out.println(al);
		
		ArrayList<Integer> a2=new ArrayList<Integer>();
		a2.add(1);
		a2.add(4);
		a2.add(7);
		a2.add(8);
		a2.add(6);
		System.out.println(a2);
		al.addAll(a2);
		System.out.println(al);
		
		Collections.sort(al);
		
		System.out.println(al);
		
		
		ArrayList<Integer> a3=new ArrayList<Integer>();
		
		a3.add(al.get(2));
		a3.add(al.get(6));
		a3.add(al.get(8));
		
		System.out.println(a3);
		
		
		//al.retainAll(a2);
		//System.out.println(al);
		
		
		//al.removeAll(a2);
		//System.out.println(al);
		
	//	int size=al.size();
	//	System.out.println(size);
		
		for(Integer a: a3)
		{
			System.out.println(a);
			
		}
		
	/*	Iterator itr=a3.iterator();
		while(itr.hasNext())
		{
			Integer a=(Integer) itr.next();
			System.out.println(a);
		}*/
		
	}

}
