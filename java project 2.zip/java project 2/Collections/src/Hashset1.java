import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;


public class Hashset1 {

	public static void main(String[] args) 
	{
		//LinkedHashSet<String> hs=new LinkedHashSet<String>();
		HashSet<String> hs=new HashSet<String>();
		hs.add("one");
		hs.add("four");
		hs.add("five");
		hs.add("eight");
		hs.add("six");
		System.out.println(hs);
		
		TreeSet<String> ts=new TreeSet<String>();
		ts.add("one");
		ts.add("four");
		ts.add("five");
		ts.add("eight");
		ts.add("six");
		System.out.println(ts);
		
		
		

	}

}
