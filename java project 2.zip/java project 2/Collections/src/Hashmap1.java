import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeMap;



public class Hashmap1 {

	public static void main(String[] args) {
		TreeMap<Integer,String> hm= new TreeMap<Integer,String>();
		//HashMap<Integer,String> hm= new HashMap<Integer,String>();
		hm.put(101, "rahul");
		hm.put(102, "tani");
		hm.put(103, "jeet");
		hm.put(104, "vinayak");
		hm.put(105, "ram");
		hm.put(105, null);
		System.out.println(hm);
		
	/*	for(Map.Entry out:hm.entrySet())
		{
			Integer key=(Integer) out.getKey();
			String value=(String) out.getValue();
			System.out.println(key);
			System.out.println(value);
			
		}*/
		
		Iterator<Integer> itr=hm.keySet().iterator();
			while(itr.hasNext())
			{
				Integer key1=itr.next();
				String value1=hm.get(key1);
				System.out.println(key1);
				System.out.println(value1);
				
			}

	}

}
