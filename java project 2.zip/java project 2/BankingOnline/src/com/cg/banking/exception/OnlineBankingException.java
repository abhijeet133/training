package com.cg.banking.exception;



public class OnlineBankingException extends Exception{

	public OnlineBankingException(String message) {
		super(message);
	}

	

}
