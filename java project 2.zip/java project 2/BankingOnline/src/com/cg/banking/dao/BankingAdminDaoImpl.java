package com.cg.banking.dao;

import java.io.IOException;
import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;









import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.banking.bean.UserBean;
import com.cg.banking.bean.UserBean1;
import com.cg.banking.dbUtil.dbUtil;
import com.cg.banking.exception.OnlineBankingException;




public class BankingAdminDaoImpl implements IBankingAdminDao {

	Logger logger=Logger.getRootLogger();
	public BankingAdminDaoImpl(){
	PropertyConfigurator.configure("log4j.properties");}
	@Override
	public int createNewAcc(UserBean ub) throws OnlineBankingException  {
		
		int nr = 0;
		Connection con;
		try {
			con = dbUtil.getConnection();
		
		
		String str = "INSERT Into Customer values(acc_id.nextval,?,?,?,?,?,?,?,?)";
		PreparedStatement pst = con.prepareStatement(str);
		pst.setInt(1,ub.getAcctype());
		pst.setInt(2,ub.getAccbal());
		pst.setDate(3,ub.getDate());
		pst.setString(4,ub.getName());	
		pst.setString(5,ub.getEmail());
		pst.setString(6,ub.getAddress());
		pst.setString(7,ub.getPancard());
		pst.setString(8,ub.getMobileno());
		
		nr = pst.executeUpdate();
		int accid = 0;
		//System.out.println(nr);
		
		
			String sql = "select acc_id.currval from Customer";
			Statement st = con.createStatement();
			ResultSet r = st.executeQuery(sql);
			while(r.next())
			{
				accid = r.getInt(1);
			}
			logger.info("Executed Succesfully");
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());

			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OnlineBankingException(e.getMessage());
		}
		return nr;
	}

	@Override
	public ArrayList<UserBean1> reteriveDaily() throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		ArrayList<UserBean1> al = new ArrayList<UserBean1>();
		try{
		Connection con = dbUtil.getConnection();
		String str = "Select * From Transactions  WHERE (trunc(sysdate)=trunc(dateoftransaction))";
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(str);
	UserBean1 ubean = null;
		//ArrayList<UserBean1> al = new ArrayList<UserBean1>();
		
		while(rs.next()){
			
			 int transactionID = rs.getInt(1);
	
			 String trandescription = rs.getString(2);
			
			 Date dateofTransaction = rs.getDate(3);
			 String transactionType = rs.getString(4);
			
			 int tranAmount = rs.getInt(5);
			
			 int accountNo = rs.getInt(6);
			
			
			 al.add(new UserBean1(transactionID, trandescription, dateofTransaction, transactionType, tranAmount, accountNo));			
			
		}
		logger.info("Executed Succesfully");
	//	System.out.println(al);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());

			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OnlineBankingException(e.getMessage());
		}
		 return al;
	}

	@Override
	public ArrayList<UserBean1> reteriveMonthly() throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		ArrayList<UserBean1> al = new ArrayList<UserBean1>();
		try{
		Connection con = dbUtil.getConnection();
		String str = "SELECT * FROM Transactions WHERE (trunc(sysdate)-trunc(dateoftransaction)<=30)";
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(str);
	UserBean1 ubean = null;
		
		
		while(rs.next()){
			
			 int transactionID = rs.getInt(1);
	
			 String trandescription = rs.getString(2);
			
			 Date dateofTransaction = rs.getDate(3);
			 String transactionType = rs.getString(4);
			
			 int tranAmount = rs.getInt(5);
			
			 int accountNo = rs.getInt(6);
			
			
			 al.add(new UserBean1(transactionID, trandescription, dateofTransaction, transactionType, tranAmount, accountNo));			
		}
		
	//	System.out.println(al);
		logger.info("Executed Succesfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());

			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OnlineBankingException(e.getMessage());
		}
		return al;
	}

	@Override
	public ArrayList<UserBean1> reteriveYearly() throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		ArrayList<UserBean1> al = new ArrayList<UserBean1>();
		try{
		Connection con = dbUtil.getConnection();
		String str = "SELECT * FROM Transactions WHERE (trunc(sysdate)-trunc(dateoftransaction)<=365)";
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(str);
	UserBean1 ubean = null;
		
		
		while(rs.next()){
			
			 int transactionID = rs.getInt(1);
	
			 String trandescription = rs.getString(2);
			
			 Date dateofTransaction = rs.getDate(3);
			 String transactionType = rs.getString(4);
			
			 int tranAmount = rs.getInt(5);
			
			 int accountNo = rs.getInt(6);
			
			
			 al.add(new UserBean1(transactionID, trandescription, dateofTransaction, transactionType, tranAmount, accountNo));			
		}
		logger.info("Executed Succesfully");
	//	System.out.println(al);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());

			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OnlineBankingException(e.getMessage());
		}
		return al;	}

	@Override
	public ArrayList<UserBean1> reteriveQuaterly() throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		ArrayList<UserBean1> al = new ArrayList<UserBean1>();
		try{
		Connection con = dbUtil.getConnection();
		String str = "SELECT * FROM Transactions WHERE (trunc(sysdate)-trunc(dateoftransaction)<=92)";
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(str);
	//UserBean1 ubean = null;
		
		
		while(rs.next()){
			
			 int transactionID = rs.getInt(1);
	
			 String trandescription = rs.getString(2);
			
			 Date dateofTransaction = rs.getDate(3);
			 String transactionType = rs.getString(4);
			
			 int tranAmount = rs.getInt(5);
			
			 int accountNo = rs.getInt(6);
			
			
			 al.add(new UserBean1(transactionID, trandescription, dateofTransaction, transactionType, tranAmount, accountNo));			
		}
		logger.info("Executed Succesfully");
	//	System.out.println(al);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());

			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OnlineBankingException(e.getMessage());
		}
		return al;	
	}

	@Override
	public int updateAccBal(UserBean ub) throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		int nr1 = 0;
		try{
		
		Connection con = dbUtil.getConnection();
		
		String str = "UPDATE customer SET account_balance=? WHERE account_id=?";
		PreparedStatement pst = con.prepareStatement(str);
	
		
		pst.setInt(1,ub.getAccbal());
		pst.setInt(2,ub.getAccid());
		
		nr1 = pst.executeUpdate();
		logger.info("Executed Succesfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());

			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OnlineBankingException(e.getMessage());
		}
		
		return nr1;
	}

	@Override
	public int updateName(UserBean ub) throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		int nr1 = 0;
		try{
		Connection con = dbUtil.getConnection();
		
		String str = "UPDATE customer SET customer_name=? WHERE account_id=?";
		PreparedStatement pst = con.prepareStatement(str);
	
		
		pst.setString(1,ub.getName());
		pst.setInt(2,ub.getAccid());
		
		nr1 = pst.executeUpdate();
		logger.info("Executed Succesfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());

			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OnlineBankingException(e.getMessage());
		}
		
		return nr1;
	}

	@Override
	public int updateAddress(UserBean ub) throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		int nr1 = 0;
		try{
		Connection con = dbUtil.getConnection();
		
		String str = "UPDATE customer SET address=? WHERE account_id=?";
		PreparedStatement pst = con.prepareStatement(str);
	
		
		pst.setString(1,ub.getAddress());
		pst.setInt(2,ub.getAccid());
		
		nr1 = pst.executeUpdate();
		logger.info("Executed Succesfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());

			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OnlineBankingException(e.getMessage());
		}
		
		return nr1;
	}

	@Override
	public int updateEmail(UserBean ub) throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		int nr1 = 0;
		try{
		Connection con = dbUtil.getConnection();
		
		String str = "UPDATE customer SET email=? WHERE account_id=?";
		PreparedStatement pst = con.prepareStatement(str);
	
		
		pst.setString(1,ub.getEmail());
		pst.setInt(2,ub.getAccid());
		
		nr1 = pst.executeUpdate();
		logger.info("Executed Succesfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());

			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OnlineBankingException(e.getMessage());
		}
		
		return nr1;
	}

	@Override
	public int updateMobileno(UserBean ub) throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		int nr1 = 0;
		try{
		Connection con = dbUtil.getConnection();
		
		String str = "UPDATE customer SET mobileno=? WHERE account_id=?";
		PreparedStatement pst = con.prepareStatement(str);
	
		
		pst.setString(1,ub.getMobileno());
		pst.setInt(2,ub.getAccid());
		
		nr1 = pst.executeUpdate();
		logger.info("Executed Succesfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());

			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OnlineBankingException(e.getMessage());
		}
		
		return nr1;
	}

	@Override
	public int updatePancard(UserBean ub) throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		int nr1 = 0;
		try{
		Connection con = dbUtil.getConnection();
		
		String str = "UPDATE customer SET pancard=? WHERE account_id=?";
		PreparedStatement pst = con.prepareStatement(str);
	
		
		pst.setString(1,ub.getPancard());
		pst.setInt(2,ub.getAccid());
		
		nr1 = pst.executeUpdate();
		logger.info("Executed Succesfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());

			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OnlineBankingException(e.getMessage());
		}
		
		return nr1;
	}

	@Override
	public int deleteAcc(UserBean ub) throws IOException, SQLException, OnlineBankingException {
		// TODO Auto-generated method stub
		int nr1 = 0;
		try{
		Connection con = dbUtil.getConnection();
		
		String str = "Delete from Customer where account_id=?";
		PreparedStatement pst = con.prepareStatement(str);
		pst.setInt(1,ub.getAccid());
		nr1 = pst.executeUpdate();
		logger.info("Executed Succesfully");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error("Exception Occured"+e.getMessage());

			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new OnlineBankingException(e.getMessage());
		}
		
		return nr1;
	}

	

}
