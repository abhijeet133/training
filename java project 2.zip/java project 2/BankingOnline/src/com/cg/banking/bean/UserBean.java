package com.cg.banking.bean;


import java.sql.Date;
import java.time.LocalDate;

public class UserBean {
	private int accid;
	private int acctype;
	private int accbal;
	private Date date;
	private String name;
	private String email;
	private String address;
	private String pancard;
	private String mobileno;
	
	

	
	
	public UserBean(int acctype, int accbal,String name,
			String email, String address, String pancard, String mobileno) {
		super();
		this.acctype = acctype;
		this.accbal = accbal;
		//this.date = date;
		this.name = name;
		this.email = email;
		this.address = address;
		this.pancard = pancard;
		this.mobileno = mobileno;
	}
	public UserBean() {
		
	}
	
	public int getAccid() {
		return accid;
	}
	public void setAccid(int accid) {
		this.accid = accid;
	}
	public int getAcctype() {
		return acctype;
	}
	public void setAcctype(int acctype) {
		this.acctype = acctype;
	}
	public int getAccbal() {
		return accbal;
	}
	public void setAccbal(int accbal) {
		this.accbal = accbal;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String getMobileno() {
		return mobileno;
	}
	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "UserBean [accid=" + accid + ", acctype=" + acctype
				+ ", accbal=" + accbal + ", name=" + name
				+ ", email=" + email + ", address=" + address + ", pancard="
				+ pancard + ", mobileno=" + mobileno + "]";
	}

	
	
	
	
	
	


	
}