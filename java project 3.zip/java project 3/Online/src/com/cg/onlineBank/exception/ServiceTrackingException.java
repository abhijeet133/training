package com.cg.onlineBank.exception;

public class ServiceTrackingException {

}
