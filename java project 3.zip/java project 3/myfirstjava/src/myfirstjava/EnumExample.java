package myfirstjava;

enum directions
{
	SOUTH,NORTH,EAST,WEST;
	
}

public class EnumExample {

	public static void main(String[] args) {
		
		//	System.out.println(directions.NORTH);
		//	System.out.println(directions.EAST);
		
		for(directions s:directions.values())
			System.out.println(s);
	}

}
