package myfirstjava;

public class User {

	public static boolean display(int a,int b)
	{
		if(a%10==b%10)
	 	{
	 		return true;
	 	}
	 	else
	 	{

	 		return false;
	 		
	 	}
		
	}

}
