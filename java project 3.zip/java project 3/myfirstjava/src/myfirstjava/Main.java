package myfirstjava;

import java.util.Scanner;

public class Main {

	public static void main(String[] args)
	{
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter first number:");
		 int a1=sc.nextInt();
		
		System.out.println("Enter second number:");
		 int b1=sc.nextInt();
		 
		 
		 boolean z=User.display(a1,b1);
		System.out.println(z);
		

	}

}
