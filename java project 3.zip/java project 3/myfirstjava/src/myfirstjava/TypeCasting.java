package myfirstjava;

public class TypeCasting {

	public static void main(String[] args) {
		
		int i=10;
		long k=i;
		System.out.println(k);
		
		float f= (float) 20.13;
	//	float ff=1.12f;
		
		long k1=(long) f;
		System.out.println(k1);	
		
		
		double d=121.11;
		int j=(int) d;
		System.out.println(j);
		

	}

}
