package myfirstjava;

public class Employee {
	
	/*void display()
	{
		
		System.out.println("HI");
	}*/
	
	/*static void dis()
	{
		System.out.println("this is static");
	}
	*/
	int empNo;
	String empName;
	static String compName="CG";
	
	Employee(int e,String n)
	{
		empNo=e;
		empName=n;
		
	}
	void display1()
	{
		System.out.println(empNo+" "+empName+" "+compName);
		
	}
	
public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Employee e = new Employee();
		
	//	e.display();
		
	//	dis();
		
		Employee e1=new Employee(111,"abc");

		Employee e2=new Employee(121,"bbc");
		
		e1.display1();
		e2.display1();
	}

}



