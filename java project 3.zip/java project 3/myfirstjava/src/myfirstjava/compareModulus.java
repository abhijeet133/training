package myfirstjava;
import java.util.Scanner;


public class compareModulus {

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter first number:");
		 int firstNumber=sc.nextInt();
		
		System.out.println("Enter second number:");
		 int secondNumber=sc.nextInt();
		 
		 	if(firstNumber%10==secondNumber%10)
		 	{
		 		System.out.println("True");
		 	}
		 	else
		 	{

		 		System.out.println("False");
		 		
		 	}
	}

}
