package myfirstjava;

public class Client {
	
	int clientId;
	String clientName, clientAddress;
	
	void display()
	{
		
		System.out.println(clientId+" "+clientName+" "+clientAddress);
	}
	
	Client(int i,String n,String a)
	{
		clientId =i;
		clientName=n;
		clientAddress=a;
		
	}
	Client()
	{
		
		
	}
	

	public static void main(String[] args) {
		
			Client c1=new Client();
			Client c2=new Client(100,"ravi","Chennai");
			
			c2.display();
			c1.display();
		

	}

}
