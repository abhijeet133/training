package myfirstjava;
import java.util.Scanner;

public class Emp {
	
	public static void main(String[] args)
	{
	 Scanner sc=new Scanner(System.in);
	 
	 System.out.println("Enter emp id : ");
	 int empId=sc.nextInt();
	 
	 System.out.println("Enter emp name :");
	 String name=sc.next();
	 
	 System.out.println("Enter salary :");
	 Float sal=sc.nextFloat();
	 
	 System.out.println("Enter grade :");
	 char grade=sc.next().charAt(0);
	 
	 System.out.println("Enter phone number :");
	 long phone=sc.nextLong();
	 
	 System.out.println("The employee details are :- "
	 		+" "+empId+" "+"\n"+name+" "+"\n"+sal+" "+"\n"+grade+" "+"\n"+phone);
	 sc.close();

	}

}
