package loggerEx;



import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Main {
	
	public static void main(String[] args) {
		
		PropertyConfigurator.configure("log4j.properties");
		Logger logger=Logger.getRootLogger();
		try{
		String s="123sa";
		int a=Integer.parseInt(s);
		logger.info("Executed succesfully");
		}
		catch(Exception e)
		{
			logger.error("Exception occured"+e.getMessage());
		}
	}

}
