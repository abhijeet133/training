package com.cg.scoreManagement.bean;

public class ScoreManagementBean {
	
	private int traineeId;
	private String moduleName;
	private double mptMarks;
	private double mttMarks;
	private double assignmentMarks;
	private double totalMarks;
	private int grade;
	
	
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getModuleName() {
		return moduleName;
	}
	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}
	public double getMptMarks() {
		return mptMarks;
	}
	public void setMptMarks(double mptMarksFinal) {
		this.mptMarks = mptMarksFinal;
	}
	public double getMttMarks() {
		return mttMarks;
	}
	public void setMttMarks(double mttMarksFinal) {
		this.mttMarks = mttMarksFinal;
	}
	public double getAssignmentMarks() {
		return assignmentMarks;
	}
	public void setAssignmentMarks(double assignmentMarksFinal) {
		this.assignmentMarks = assignmentMarksFinal;
	}
	public double getTotalMarks() {
		return totalMarks;
	}
	public void setTotalMarks(double totalMarks2) {
		this.totalMarks = totalMarks2;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	
	

}
