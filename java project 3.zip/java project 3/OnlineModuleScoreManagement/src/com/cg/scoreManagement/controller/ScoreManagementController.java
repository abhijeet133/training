package com.cg.scoreManagement.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;








import com.cg.scoreManagement.bean.ScoreManagementBean;
import com.cg.scoreManagement.exception.ScoreManagementException;
import com.cg.scoreManagement.service.IScoreManagementService;
import com.cg.scoreManagement.service.ScoreManagementServiceImpl;


@WebServlet("*.obj")
public class ScoreManagementController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		ScoreManagementBean bean=new ScoreManagementBean();
		
		IScoreManagementService service= new ScoreManagementServiceImpl();
		
		HttpSession session=request.getSession();
		
		String target=null;
		String path=request.getServletPath();
		switch(path)
		{
		case "/addAssessmentdetails.obj" :
			
			
			ArrayList<Integer> list=null;
			
			
			
			
			 
			try {
			list=service.retrieveTraineeId();
			}
			
			catch (ScoreManagementException e) {
				
				session.setAttribute("error", e.getMessage());
				target="Error.jsp";
				
			}
			session.setAttribute("list", list);
			
			
			
			target="AddAssessment.jsp";
			break;
			
		case "/details.obj" :
			
			
			String traineeId=request.getParameter("traineeId");
			int traineeIdInteger=Integer.parseInt(traineeId);
				
				
				String moduleName=request.getParameter("txtModule");
				
				
				String mptMarks=request.getParameter("mptMarks");
				double mptMarksInteger=	Double.parseDouble(mptMarks);
				
				
				
				
				
				String mttMarks=request.getParameter("mttMarks");
				double mttMarksInteger=	Double.parseDouble(mttMarks);
				
				String assignmentMarks=request.getParameter("assignmentMarks");
				double assignmentMarksInteger=	Double.parseDouble(assignmentMarks);
				
				double mptMarksFinal=service.calMpt(mptMarksInteger);
				double mttMarksFinal=service.calMtt(mttMarksInteger);
				double assignmentMarksFinal=service.calAssignment(assignmentMarksInteger);
				
				double totalMarks=service.totalCal(mptMarksFinal,mttMarksFinal,assignmentMarksFinal);
				
				int grade=service.gradeCal(totalMarks);
				
				
					bean.setTraineeId(traineeIdInteger);;
					bean.setModuleName(moduleName);
					bean.setMptMarks(mptMarksFinal);
					bean.setMttMarks(mttMarksFinal);
					bean.setAssignmentMarks(assignmentMarksFinal);
					bean.setTotalMarks(totalMarks);
					bean.setGrade(grade);
			
			try{
				
				
				
				int res=service.addAssessmentDetails(bean);
				
				if(res==0)
				{
					String m="Module is already assing";
					session.setAttribute("error",m);
					target="index.jsp";
					
					
				}
				else
				{
					
					session.setAttribute("traineeId", traineeIdInteger);
					session.setAttribute("moduleName", moduleName);
					
					session.setAttribute("totalMarks", totalMarks);
					session.setAttribute("grade", grade);
					
				
				
					
					
					target="ModuleScore.jsp";
				}
			}
			
			catch (ScoreManagementException e) {
				session.setAttribute("error", e.getMessage());
				target="Error.jsp";
			}
	
				break;
			
			
		
			

				
			
		
			
				
		}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
	}
	
		
	}

	


