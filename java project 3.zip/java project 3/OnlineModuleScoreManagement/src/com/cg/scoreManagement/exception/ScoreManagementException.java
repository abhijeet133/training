package com.cg.scoreManagement.exception;



@SuppressWarnings("serial")
public class ScoreManagementException extends Exception{
	public ScoreManagementException(String message)
	{
		super(message);
	}
}
