package com.cg.scoreManagement.dao;

import java.util.ArrayList;

import com.cg.scoreManagement.bean.ScoreManagementBean;
import com.cg.scoreManagement.exception.ScoreManagementException;

/**
 * Author		:	Abhijeet Anand
 * Class Name	:	IScoreManagementDao
 * Package		:	com.cg.scoreManagement.dao
 * Date			:	oct 11, 2017
 */

public interface IScoreManagementDao {
	
	public ArrayList<Integer> retrieveTraineeId() throws ScoreManagementException;
	
	public int addAssessmentDetails(ScoreManagementBean bean) throws ScoreManagementException;

	

}
