package com.cg.scoreManagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;








import com.cg.scoreManagement.DbUtil.DbUtil;
import com.cg.scoreManagement.bean.ScoreManagementBean;
import com.cg.scoreManagement.exception.ScoreManagementException;

/**
 * Author		:	Abhijeet Anand
 * Class Name	:	ScoreManagementDaoImpl
 * Package		:	com.cg.scoreManagement.dao
 * Date			:	oct 11, 2017
 */

public class ScoreManagementDaoImpl implements IScoreManagementDao {
	Connection conn=null;
	//---------------- 1. Fetched trainee Id ---------------
		/**************************************************************
		 - Method Name		:	retrieveTraineeId()
		 - Input Parameters	:	
		 - Return Type		:	list
		 - Throws			:   ScoreManagementException
		 - Author			:	Emp-ID: 135699
		 - Creation Date	:	oct 11, 2017
		 - Description		:	All trainee id fetched 
		 *************************************************************/	
	@Override
	public ArrayList<Integer> retrieveTraineeId() throws ScoreManagementException{
		
		ArrayList<Integer> list=new ArrayList<Integer>();
		try {
			conn=DbUtil.getConnection();
		
		
		String sql="Select trainee_id from trainees";
		
		
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(sql);
	
		
		while(rs.next())
		{
			int traineeId=rs.getInt(1);		
			list.add(traineeId);
		}
		
		
		}
		catch (SQLException e)
		{
			
			throw new ScoreManagementException("ERROR:" + e.getMessage());
		}
		
		return list;
		
	}
	//---------------- 2. Insert Trainee details ---------------
			/**************************************************************
			 - Method Name		:	addAssessmentDetails()
			 - Input Parameters	:	bean
			 - Return Type		:	int
			 - Throws			:   ScoreManagementException
			 - Author			:	Emp-ID: 135699
			 - Creation Date	:	oct 11, 2017
			 - Description		:	Assessment is added
			 *************************************************************/	
	@Override
	public int addAssessmentDetails(ScoreManagementBean bean) throws ScoreManagementException{
		
		
		int row=0;
		int TraineeId=0;
		String ModuleName=null;
		conn=DbUtil.getConnection();
		
		{	
			
		try {	
			
			
			String sql="Select * from AssessmentScore";
			
			
			
			
				Statement st;
				st = conn.createStatement();
			
			ResultSet rs=st.executeQuery(sql);
		
			
			while(rs.next())
			{
				 TraineeId=rs.getInt(1);
				 ModuleName=rs.getString(2);
						
			}
			} catch (SQLException e1) {
				
				e1.printStackTrace();
			}
		}
		
		if(TraineeId==bean.getTraineeId())
			{
				if(ModuleName==bean.getModuleName())
				{
				row=0;
			
				}
			}	
		else
		{
			try{
			
			String insertQuery= "insert into AssessmentScore values(?,?,?,?,?,?,?)";
			
			PreparedStatement ps= conn.prepareStatement(insertQuery);
			ps.setInt(1, bean.getTraineeId());
			ps.setString(2, bean.getModuleName());
			ps.setFloat(3,(float) bean.getMptMarks());
			ps.setFloat(4,(float) bean.getMttMarks());
			ps.setFloat(5,(float) bean.getAssignmentMarks());
			ps.setFloat(6,(float) bean.getTotalMarks());
			ps.setInt(7,bean.getGrade());
			row=ps.executeUpdate();
			
			
			
		
		}
			
		catch(SQLException e){
			
			throw new ScoreManagementException("ERROR:" + e.getMessage());
			
		}
			}
	
		
		
		return row;

		
	}

}
