package com.cg.scoreManagement.service;

import java.util.ArrayList;






import com.cg.scoreManagement.bean.ScoreManagementBean;
import com.cg.scoreManagement.dao.IScoreManagementDao;
import com.cg.scoreManagement.dao.ScoreManagementDaoImpl;
import com.cg.scoreManagement.exception.ScoreManagementException;


/**
 * Author		:	Abhijeet Anand
 * Class Name	:	ScoreManagementServiceImpl
 * Package		:	com.cg.scoreManagement.service
 * Date			:	oct 11, 2017
 */

public class ScoreManagementServiceImpl implements IScoreManagementService {
	
	
	
	IScoreManagementDao dao=null;

	@Override
	public ArrayList<Integer> retrieveTraineeId() throws ScoreManagementException {
		
		dao=new ScoreManagementDaoImpl();
		return dao.retrieveTraineeId();
		
	}

	@Override
	public int addAssessmentDetails(ScoreManagementBean bean) throws ScoreManagementException {
		
		dao=new ScoreManagementDaoImpl();
		return dao.addAssessmentDetails(bean);
		
	}

	@Override
	public double calMpt(double mptMarksInteger) {
		return(0.7*mptMarksInteger);
	}

	@Override
	public double calMtt(double mttMarksInteger) {
		return(0.15*mttMarksInteger);
	}

	@Override
	public double calAssignment(double assignmentMarksInteger) {
		return(0.15*assignmentMarksInteger);
	}

	@Override
	public double totalCal(double mptMarksFinal, double mttMarksFinal,
			double assignmentMarksFinal) {
		
		return(mptMarksFinal+mttMarksFinal+assignmentMarksFinal);
		
	}

	@Override
	public int gradeCal(double totalMarks) {
			int grade=0;
		
		
		if(totalMarks>=90)
		{
			grade=5;
			return grade;
		}
		else if(totalMarks>=80)
		{
			grade=4;
			return grade;
		}
		else if(totalMarks>=70)
		{
			grade=3;
			return grade;
		}
		else if(totalMarks>=60)
		{
			grade=2;
			return grade;
		}
		else if(totalMarks>=50)
		{
			grade=1;
			return grade;
		}
		else
		{
			grade=0;
			return grade;
		}
		
	}

	

	

}
