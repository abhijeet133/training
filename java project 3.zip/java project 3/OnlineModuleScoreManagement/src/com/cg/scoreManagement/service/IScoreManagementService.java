package com.cg.scoreManagement.service;

import java.util.ArrayList;



import com.cg.scoreManagement.bean.ScoreManagementBean;
import com.cg.scoreManagement.exception.ScoreManagementException;


/**
 * Author		:	Abhijeet Anand
 * Class Name	:	IScoreManagementService
 * Package		:	com.cg.scoreManagement.service
 * Date			:	oct 11, 2017
 */

public interface IScoreManagementService {
	
public ArrayList<Integer> retrieveTraineeId() throws ScoreManagementException;
	
	public int addAssessmentDetails(ScoreManagementBean bean) throws ScoreManagementException;

	public double calMpt(double mptMarksInteger);

	public double calMtt(double mttMarksInteger);

	public double calAssignment(double assignmentMarksInteger);

	public double totalCal(double mptMarksFinal, double mttMarksFinal,
			double assignmentMarksFinal);

	public int gradeCal(double totalMarks);

	

}
