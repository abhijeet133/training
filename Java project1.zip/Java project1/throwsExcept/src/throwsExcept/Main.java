package throwsExcept;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Main {

	public static void main(String[] args) throws ParseException {
		
		String s="10-12-2012";
		SimpleDateFormat sdf= new SimpleDateFormat("dd/mm/yyyy");
		Date d1=sdf.parse(s);
		System.out.println(d1);
	}

}
