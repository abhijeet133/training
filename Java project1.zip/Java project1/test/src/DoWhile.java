import java.util.Scanner;
import java.util.TreeSet;



public class DoWhile {
public static void main (String [] args) {
	/*int a='b';
	long l=a;
	char c=a;
	
	
	double d=4.8;
	float f=d;
	
	int a1=(int)3.8;
	System.out.println(a1);
	int a11=0b1_0_1_1;
	int b11=0b1_0_1_1_0;
	
	System.out.println(a11+b11);
	
	String s=null;
	String s1=(String)s;
	System.out.println(s1);
	
	String s="hello";
	String s1=new String("hello");
	String s2=s1;
	System.out.println(s==s1);

	System.out.println(s==s2);

	System.out.println(s1==s2);

	System.out.println(s.equals(s1));
	
	
	
	
	
	Scanner scanner = new Scanner("1, 2, 3, 4, 5, 6,7,8").useDelimiter(", ");
	while (scanner.hasNextInt()) {
	int num = scanner.nextInt();
	if (num % 2 == 0)
	System.out.println(num);
	}
	
	
	


		class Mixer {
		Mixer() { }
		Mixer(Mixer m) { m1 = m; }
		Mixer m1;
	
		Mixer m2 = new Mixer();
		Mixer m3 = new Mixer(m2); m3.go();
		Mixer m4 = m3.m1; m4.go();
		Mixer m5 = m2.m1; m5.go();
		}
		void go() { System.out.print("hi "); }
		
	

TreeSet z=new TreeSet();


employee e=new employee();
employee e1=new employee();

z.add(e);


z.add(null);


HashTable obj=new HashTable();
*/


	String s="hello";
	String s1=new String ("hello");
	String s2=s1;
	
	System.out.println(s==s1);
	System.out.println(s==s2);
	System.out.println(s1==s2);
	System.out.println(s.equals(s1));
	System.out.println(s.equals(s2));
	System.out.println(s1.equals(s2));
	
	


}
}
