
public class Overloading1 {
	
	
	public static void main(String[] args) {
		
		Addition a= new Addition();
		int b= a.add(10,20);
		int c= a.add(10, 20, 30);
		
		System.out.println(b);
		System.out.println(c);
		
		
	}

}
class Addition
{
	
	int add(int a,int b)
	{
		return a+b;
	}
	int add(int a,int b,int c)
	{
		return a+b+c;
	}
}
