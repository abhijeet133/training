
public class overriding1 {
	
public static void main(String[] args) {
		
		bike b = new bike();
		b.speed();
		
		
	}

}
class car
	{
		public void speed()
			{
				System.out.println("car class");
			}
	}
class bike extends car
	{
		public void speed()
		{
			System.out.println("bike class");
		}
	}
