package com.cg.day3Session;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/welcomeServlet")
public class welcomeServlet extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
	HttpSession session=request.getSession(false);
		//String u=(String) session.getAttribute("user");
		
		//String e=(String) session.getAttribute("email");
		
		Cookie ck[]=request.getCookies();
		for(Cookie c:ck)
		{
			
			out.print(c.getName());
			out.print(c.getValue());
		}
		
		
		
		//out.print("UserName- "+u+"<br>");
	//	out.print("Email- "+e);
		
		
		
		
	}

}
