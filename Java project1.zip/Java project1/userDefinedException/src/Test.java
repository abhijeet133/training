import java.util.ArrayList;
 import java.util.List;
 public class Test{ 
       public static void main(String args[]) {
        List<Integer> list = new ArrayList<Integer>(); 
    list.add(0, 59);
    int total = list.get(0);
    System.out.println(total);  
     }
}