package com.cg.exam.service;

import java.util.ArrayList;

import com.cg.exam.bean.StudentExamBean;


public interface IStudentExamService {
	
	public ArrayList<Integer> retrieveStudentId();
	public int addStudentExamDetails(StudentExamBean bean);
	
	public int totalCal(int tMarks, int lMarks, int aMarks);
	public String gradeCal(int totalScore);
	public ArrayList<StudentExamBean> retrieveDetails();
	
	
	
	
	

}
