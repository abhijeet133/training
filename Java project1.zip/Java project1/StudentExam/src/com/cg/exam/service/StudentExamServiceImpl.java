package com.cg.exam.service;

import java.util.ArrayList;

import com.cg.exam.bean.StudentExamBean;
import com.cg.exam.dao.IStudentExamDao;
import com.cg.exam.dao.StudentExamDaoImpl;






public class StudentExamServiceImpl implements IStudentExamService {

	IStudentExamDao dao=null;
	@Override
	public ArrayList<Integer> retrieveStudentId() {
		dao=new StudentExamDaoImpl();
		return dao.retrieveStudentId();
	}
	@Override
	public int addStudentExamDetails(StudentExamBean bean) {
		dao=new StudentExamDaoImpl();
		return dao.addStudentExamDetails(bean);
	}
	@Override
	public int totalCal(int tMarks, int lMarks, int aMarks) {
		int totalScore=tMarks+lMarks+aMarks;
		return totalScore;
	}
	@Override
	public String gradeCal(int totalScore) 
	{
		String grade=null;
		
		
		if(totalScore>91)
		{
			grade="S";
			return grade;
		}
		else if(totalScore>81)
		{
			grade="A";
			return grade;
		}
		else if(totalScore>71)
		{
			grade="B";
			return grade;
		}
		else if(totalScore>61)
		{
			grade="C";
			return grade;
		}
		else if(totalScore>51)
		{
			grade="D";
			return grade;
		}
		else
		{
			grade="U";
			return grade;
		}
		
	}
	@Override
	public ArrayList<StudentExamBean> retrieveDetails() {
		dao=new StudentExamDaoImpl();
		return dao.retrieveDetails();
	}
	
	

}
