package com.cg.exam.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.exam.bean.StudentExamBean;
import com.cg.exam.service.IStudentExamService;
import com.cg.exam.service.StudentExamServiceImpl;




@WebServlet("*.obj")
public class StudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		StudentExamBean bean=new StudentExamBean();
		
		IStudentExamService service= new StudentExamServiceImpl();
		
		HttpSession session=request.getSession();
		
		String target=null;
		String path=request.getServletPath();
		switch(path)
		{
		case "/addStudentExam.obj" :
			
			
			ArrayList<Integer> list=null;
			
			list=service.retrieveStudentId();
			session.setAttribute("list", list);
			
			
			
			target="addStudentExamDetails.jsp";
			break;
			
		case "/details.obj" :
			
			
			String studentId=request.getParameter("studentId");
			int cId=Integer.parseInt(studentId);
				
				
				String subject=request.getParameter("txtSubject");
				
				
				String theoryMarks=request.getParameter("theoryMarks");
				int tMarks=Integer.parseInt(theoryMarks);
				
				
				
				String labMarks=request.getParameter("labMarks");
				int lMarks=Integer.parseInt(labMarks);
				
				String assignmentMarks=request.getParameter("assignmentMarks");
				int aMarks=Integer.parseInt(assignmentMarks);
				
				int totalScore=service.totalCal(tMarks,lMarks,aMarks);
				
				String grade=service.gradeCal(totalScore);
				
				
			bean.setStudentId(cId);
			bean.setSubject(subject);
			bean.setTheoryScore(tMarks);
			bean.setLabScore(lMarks);
			bean.setAssignmentScore(aMarks);
			bean.setTotalScore(totalScore);
			bean.setGrade(grade);
			
			
				
				
				
				int res=service.addStudentExamDetails(bean);
				
				if(res==0)
				{
					target="Error.html";
					
					
				}
				else
				{
					
					session.setAttribute("cId", cId);
					session.setAttribute("subject", subject);
					
					session.setAttribute("totalScore", totalScore);
					session.setAttribute("grade", grade);
					ArrayList<StudentExamBean> list1=null;
					
					list1=service.retrieveDetails();
				
				
					session.setAttribute("list1", list1);
					
					target="resultScore2.jsp";
				}
				
				break;
			
			
		
			

				
			
		
			
				
		}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
	}
		
		
	}

	


