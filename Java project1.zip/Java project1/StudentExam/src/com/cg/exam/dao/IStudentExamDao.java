package com.cg.exam.dao;

import java.util.ArrayList;

import com.cg.exam.bean.StudentExamBean;






public interface IStudentExamDao {
	
	public ArrayList<Integer> retrieveStudentId();
	
	public int addStudentExamDetails(StudentExamBean bean);

	public ArrayList<StudentExamBean> retrieveDetails();

}
