package com.cg.exam.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.cg.exam.DbUtil.DbUtil;
import com.cg.exam.bean.StudentExamBean;





public class StudentExamDaoImpl implements IStudentExamDao {
	Connection conn=null;
	
	@Override
	public ArrayList<Integer> retrieveStudentId() {
		ArrayList<Integer> list=new ArrayList<Integer>();
		try {
			conn=DbUtil.getConnection();
		
		
		String sql="Select studentId from StudentExam";
		
		
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(sql);
	
		
		while(rs.next())
		{
			int studentId=rs.getInt(1);		
			list.add(studentId);
		}
		
		
		}
		catch (SQLException e)
		{
			
			System.out.println(e.getMessage());
		}
		
		return list;
		
	}
	
		
	
	
	@Override
	public int addStudentExamDetails(StudentExamBean bean) {
		int row=0;

		
			
			
			try{
				
				conn=DbUtil.getConnection();
				
				String insertQuery= "insert into StudentScoreDetail values(?,?,?,?,?,?,?)";
				
				PreparedStatement ps= conn.prepareStatement(insertQuery);
				ps.setInt(1, bean.getStudentId());
				ps.setString(2, bean.getSubject());
				ps.setInt(3,bean.getTheoryScore());
				ps.setInt(4,bean.getLabScore());
				ps.setInt(5,bean.getAssignmentScore());
				ps.setInt(6,bean.getTotalScore());
				ps.setString(7,bean.getGrade());
				row=ps.executeUpdate();
				
				
				
			
			}
			catch(SQLException e){
				
				System.out.println("e.getMessage()");
				
			}
			
			
			return row;

		
	}




	@Override
	public ArrayList<StudentExamBean> retrieveDetails() {
		ArrayList<StudentExamBean> list=new ArrayList<StudentExamBean>();
		try {
			conn=DbUtil.getConnection();
		
		
		String sql="Select * from StudentScoreDetail";
		
		
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(sql);
	
		
		while(rs.next())
		{
			int StudentId=rs.getInt(1);
			String Subject=rs.getString(2);
			int TheoryScore=rs.getInt(3);
			int labScore=rs.getInt(4);
			int asngMarks=rs.getInt(5);
			int totalMarks=rs.getInt(6);
			String grade=rs.getString(7);
			
			
			
			
			list.add(new StudentExamBean(StudentId,Subject,TheoryScore,labScore,asngMarks,totalMarks,grade));
		}
		
		
		}
		catch (SQLException e)
		{
			
			System.out.println(e.getMessage());
		}
		
		return list;
		
	}
	}





	

