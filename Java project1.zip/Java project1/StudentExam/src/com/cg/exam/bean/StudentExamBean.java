package com.cg.exam.bean;

public class StudentExamBean 
{
	private int studentId;
	private String subject;
	private int theoryScore;
	private int labScore;
	private int assignmentScore;
	private int totalScore;
	private String grade;
	
	
	
	


	public int getStudentId() {
		return studentId;
	}






	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}






	public String getSubject() {
		return subject;
	}






	public void setSubject(String subject) {
		this.subject = subject;
	}






	public int getTheoryScore() {
		return theoryScore;
	}






	public void setTheoryScore(int theoryScore) {
		this.theoryScore = theoryScore;
	}






	public int getLabScore() {
		return labScore;
	}






	public void setLabScore(int labScore) {
		this.labScore = labScore;
	}






	public int getAssignmentScore() {
		return assignmentScore;
	}






	public void setAssignmentScore(int assignmentScore) {
		this.assignmentScore = assignmentScore;
	}






	public int getTotalScore() {
		return totalScore;
	}






	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}






	public String getGrade() {
		return grade;
	}






	public void setGrade(String grade) {
		this.grade = grade;
	}


	



	public StudentExamBean(int studentId, String subject, int theoryScore,
			int labScore, int assignmentScore, int totalScore, String grade) {
		super();
		this.studentId = studentId;
		this.subject = subject;
		this.theoryScore = theoryScore;
		this.labScore = labScore;
		this.assignmentScore = assignmentScore;
		this.totalScore = totalScore;
		this.grade = grade;
	}












	public StudentExamBean()
	{
		
	}
	
}
