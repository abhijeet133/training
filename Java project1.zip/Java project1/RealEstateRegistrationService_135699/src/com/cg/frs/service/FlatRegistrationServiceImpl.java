package com.cg.frs.service;

import java.util.ArrayList;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FrsException;





public class FlatRegistrationServiceImpl implements IFlatRegistrationService {
	
	
	IFlatRegistrationDAO dao=null;
/************************************************************************	
	-Function Name    : registerFlat()
	-Input Parameters : FlatRegistrationDTO f
	-Return Type      : integer
	-Throws           : FrsException
	-Author           : Abhijeet Anand
	-creation Date    : 27/09/2017
	-Description      : Adding Flat Registration
*************************************************************************/
	
	@Override
	public int registerFlat(FlatRegistrationDTO f) throws FrsException {
		
		dao=new FlatRegistrationDAOImpl();
		
		return dao.registerFlat(f);
	}

	
/************************************************************************	
	-Function Name    : getAllOwnerIds()
	-Input Parameters : 
	-Return Type      : ArrayList
	-Throws           : FrsException
	-Author           : Abhijeet Anand
	-creation Date    : 27/09/2017
	-Description      : Retriving Flat Owners
*************************************************************************/	
	@Override
	public ArrayList<Integer> getAllOwnerIds() throws FrsException{
		
			dao=new FlatRegistrationDAOImpl();
		
	
		return dao.getAllOwnerIds();
			
	}

	//Owner Id validation
	@Override
	public boolean validateOwnerId(int OwnerId, ArrayList<Integer> list) {
		boolean flag=false;
		for(Integer out:list)
		{
			if(out == OwnerId)
			{
				flag=true;
				break;
			}
			
		}
		
		return flag;
	}
//Deposit Amount must be greater than Rent Amount validation 
	@Override
	public boolean validateAmount(int rentAmount, int depositeAmount) {
		if(depositeAmount>rentAmount)
		{
			return true;
		}
		else
		{
			System.out.println("Deposit Amount cannot be less than rent amount");
			return false;
		}
		
	}
	
//validate flat Area

	@Override
	public boolean validateFlatArea(int flatArea) {
		
		
		if(flatArea<=0)
		{
			System.out.println("Flat area must be greater then 0");
			return false;
			
		}
		else
		{
			
			
			return true;
			
		}
	}
		
	
//validate Flat Type
	@Override
	public boolean validateFlatType(int FlatType) {
		
		if(FlatType==1 ||FlatType==2)
		{
			return true;
			
		}
		else
		{
			System.out.println("Enter Flat type as displayed");
			return false;
		}
		
	}

	//validate Desired Rent Amount 
	@Override
	public boolean validateDesiredRentAmount(int dRentAmount) {
		if(dRentAmount<=0)
		{
			System.out.println("Please enter desire Rent amount greater then 0");
			return false;
		}
		else
		{
			return true;
		}
	}}
