package com.cg.frs.service;

import java.util.ArrayList;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FrsException;

public interface IFlatRegistrationService {
	
	public int registerFlat(FlatRegistrationDTO f) throws FrsException;
	public ArrayList<Integer> getAllOwnerIds() throws FrsException;
	
	public boolean validateOwnerId(int OwnerId, ArrayList<Integer> list);
	public boolean validateAmount(int rentAmount,int depositeAmount);
	
	public boolean validateFlatArea(int flatArea);
	public boolean validateFlatType(int FlatType);
	public boolean validateDesiredRentAmount(int dRentAmount);

}
