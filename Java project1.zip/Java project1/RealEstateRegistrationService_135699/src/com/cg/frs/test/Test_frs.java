package com.cg.frs.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FrsException;




public class Test_frs {

	static IFlatRegistrationDAO dao=null;
	static FlatRegistrationDTO bean=null;
	
	@BeforeClass
	public static void initilize()  {
		
		dao=new FlatRegistrationDAOImpl();
		bean=new FlatRegistrationDTO();
	}
	@Test
	public void test()
	{
		bean.setFlatRegNo(1000);
		bean.setOwnerId(1001);
		bean.setFlatType(1);
		bean.setFlatArea(100);
		bean.setRentAmount(500);
		bean.setDepositAmount(1000);

	}
	
	@Test
	public void testAddDetails()
	{
		

			try {
				assertNotNull(dao.registerFlat(bean));
			} catch (FrsException e) {
				
				//System.out.println("Test case");
			}
			
	}
	
	@Test
	public void getDetails() throws FrsException
	{
		
			assertNotNull(dao.getAllOwnerIds());
		
	}
	@AfterClass
	public static void test3()
	{
		System.out.println("After class");
	}

}
