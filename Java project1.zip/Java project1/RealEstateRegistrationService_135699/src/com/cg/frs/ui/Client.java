package com.cg.frs.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FrsException;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;






public class Client {
	
static Scanner sc=new Scanner(System.in);
	
	
	public static void main(String[] args) throws FrsException  {
		
		//Client UI
		System.out.println("Real Estate Registration Service");
		System.out.println("***********************************");
		while(true)
		{
			System.out.println("1.Register Flat");
			System.out.println("2.Exit");	
			
			System.out.println("Enter your choice");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1: registerFlat();
			break;

			case 2: 
				System.out.println("Thank you for visiting us!!!!!");	
				System.exit(0);
			break;
			
			}
			
		}

	}


	private static void registerFlat() throws FrsException {
		
		IFlatRegistrationService service= new FlatRegistrationServiceImpl();
		
		ArrayList<Integer> list=null;
		
		
		try {
			list=service.getAllOwnerIds();
		
	
		{
			
			System.out.println("Existing Owner IDS Are:-"+list);
				
		}
		
		
		System.out.println("Please enter your owner id from above list: ");
		int OwnerId=sc.nextInt();
		
		if(service.validateOwnerId(OwnerId,list))
		{
		
		System.out.println("Select Flat Type(1-1BHK,2-2BHK): ");
		int flatType=sc.nextInt();
		if(service.validateFlatType(flatType))
		{
		
		System.out.println("Enter Flat area in sq. ft.: ");
		int flatArea=sc.nextInt();
		if(service.validateFlatArea(flatArea))
		{
		System.out.println("Enter desired rent amount Rs: ");
		int dRentAmount=sc.nextInt();
		if(service.validateDesiredRentAmount(dRentAmount))
		{
		System.out.println("Enter desired deposit amount Rs: ");
		int dDepositeAmount=sc.nextInt();
		if(service.validateAmount(dRentAmount, dDepositeAmount))
		{
	
		
		FlatRegistrationDTO details=new FlatRegistrationDTO(OwnerId,flatType,flatArea,dRentAmount,dDepositeAmount);
		
		int result=service.registerFlat(details);

		if(result==0)
		{	
			System.out.println("value not added");
		}
		else
		{
			System.out.println("**************************************************************");
			System.out.println("Flat successfully registered. Registration id:<"+result+">");
			
			System.out.println("**************************************************************");	
			
		}
		}
		
		}
		}}
		
		
		}
		
		else
		{
			System.out.println("owner does not exists");

		}
		}
		catch (FrsException e) {
		System.out.println("Exception occured"+e);
	}
		
		
		
		
	}}
	

