package com.cg.frs.dao;

import java.util.ArrayList;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FrsException;



public interface IFlatRegistrationDAO {
	
	public int registerFlat(FlatRegistrationDTO f) throws FrsException;
	public ArrayList<Integer> getAllOwnerIds() throws FrsException;

}
