package com.cg.frs.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.frs.dbUtil.DbUtil;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FrsException;




public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO {
	
	int result=0;
	Connection conn=null;
	int registrationId=0;
	
	Logger logger=Logger.getRootLogger();
	public FlatRegistrationDAOImpl()
	{
		PropertyConfigurator.configure("log4j.properties");
	}

/************************************************************************	
	-Function Name    : registerFlat()
	-Input Parameters : FlatRegistrationDTO f
	-Return Type      : integer
	-Throws           : FrsException
	-Author           : Abhijeet Anand
	-creation Date    : 27/09/2017
	-Description      : Adding Flat Registration
*************************************************************************/	
	@Override
	public int registerFlat(FlatRegistrationDTO f) throws FrsException {
		
		
		try{
			
			conn=DbUtil.getConnection();
		
		 
		String insertQuery="Insert into Flat_Registration values(FLAT_SEQ.nextval,?,?,?,?,?)";
				
				PreparedStatement ps=conn.prepareStatement(insertQuery,new String[] {"flat_reg_no"});
				ps.setInt(1, f.getOwnerId());
				ps.setInt(2,f.getFlatType());
				ps.setInt(3,f.getFlatArea());
				ps.setInt(4,f.getRentAmount());
				ps.setInt(5,f.getDepositAmount());
				
				
				
				result=ps.executeUpdate();
				
				ResultSet rs = ps.getGeneratedKeys();
				if (rs.next()) 
				{
					
					registrationId = rs.getInt(1);
				}
				logger.info("Executed succesfully");
				
		}
		
		catch (SQLException e) {
			//logger info
			logger.error("Exception occured"+e.getMessage());
			throw new FrsException("invalid column");
		
			
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		
		return registrationId;
		
	}
/************************************************************************	
	-Function Name    : getAllOwnerIds()
	-Input Parameters : 
	-Return Type      : ArrayList
	-Throws           : FrsException
	-Author           : Abhijeet Anand
	-creation Date    : 27/09/2017
	-Description      : Retriving Flat Owners
*************************************************************************/
	
	
	@Override
	public ArrayList<Integer> getAllOwnerIds() throws FrsException{
		
		ArrayList<Integer> list=new ArrayList<Integer>();
		
		try {
			conn=DbUtil.getConnection();
		
	
	
	String sql="Select * from FLAT_OWNERS";
	
	
	Statement st=conn.createStatement();
	ResultSet rs=st.executeQuery(sql);

	
	while(rs.next())
	{
		
		int ownerId=rs.getInt(1);

		
		list.add(new Integer(ownerId));
		//logger info
		logger.info("Executed succesfully");
		
		
	}
	
		}
		 catch (IOException | SQLException e) {
			//logger info
			 logger.error("Exception occured"+e.getMessage());
			 throw new FrsException("invalid column");
							
			}
		return list;
			}
		
	}


