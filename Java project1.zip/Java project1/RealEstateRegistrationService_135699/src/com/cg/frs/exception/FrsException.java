package com.cg.frs.exception;

public class FrsException extends Exception{
	
	
	public FrsException(String msg)
	{
		super(msg);
	}

}
