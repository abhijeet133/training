package regularExp;
//import java.util.regex.Pattern;
import java.util.regex.*;


public class Main {

	public static void main(String[] args) {
		//pattern class
		String s="capgemini";
		String pattern="[a-z]{2,}";
		boolean b=Pattern.matches(pattern, s);
		System.out.println(b);
		
		String phone="9709981803";
		String reg="[789]{1}[0-9]{9}";
		boolean b1=Pattern.matches(reg, phone);
		System.out.println(b1);
		
		String digit="[0-9]*";
		String digitinput="965dsds";
		boolean b2=Pattern.matches(digit, digitinput);
		System.out.println(b2);
		
		String s1="Capgemini";
		String p1="[A-Z]{1}[a-z]{2,}";
		boolean b4=Pattern.matches(p1,s1);
		System.out.println(b4);
		
		//matcher class
		
		Pattern p=Pattern.compile("[0-9]{1}[a-zA-Z]{3,}");
		Matcher m=p.matcher("1abcAB");
		boolean b3=m.matches();
		System.out.println(b3);
		
		
		
		
	}

}
