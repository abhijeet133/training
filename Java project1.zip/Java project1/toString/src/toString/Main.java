package toString;

public class Main {

	public static void main(String[] args) {
		
		Student s1=new Student(111,"raj");

		Student s2=new Student(111,"raj");
		
		System.out.println(s1);
		System.out.println(s2);
		
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		
		boolean b= s1.equals(s2);
		System.out.println(b);
		
	}

}
