package com.cg.student.dao;

import java.util.ArrayList;


import com.cg.student.bean.StudentBean;



public interface IStudentDao 
{
	public int insertStudent(StudentBean bean);
	public ArrayList<StudentBean> retrieveDetails();
	
}
