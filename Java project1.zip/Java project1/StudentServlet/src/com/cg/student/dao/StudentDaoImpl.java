package com.cg.student.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;




import java.sql.Statement;
import java.util.ArrayList;


import com.cg.student.DbUtil.DbUtil;
import com.cg.student.bean.StudentBean;

public class StudentDaoImpl implements IStudentDao {
	Connection conn=null;
	@Override
	public int insertStudent(StudentBean bean) 
	
	{
		int row=0;

		int id=0;
			
			
			try{
				
				conn=DbUtil.getConnection();
				
				String insertQuery= "insert into Student_score values(seq_studId.nextval,?,?,?,?,?,?,?)";
				
				PreparedStatement ps= conn.prepareStatement(insertQuery,new String[]{"studentId"});
				ps.setString(1, bean.getStudentName());
				ps.setInt(2, bean.getAge());
				ps.setString(3,bean.getState());
				ps.setString(4,bean.getGender());
				ps.setInt(5,bean.getNoOfSubject());
				ps.setInt(6,bean.getNoOfAttempt());
				ps.setInt(7,bean.getTotalSubject());
				row=ps.executeUpdate();
				
				ResultSet rs=ps.getGeneratedKeys();
				if(rs.next())
				{
					id=rs.getInt(1);
				}
			
			}
			catch(SQLException e){
				
				System.out.println("e.getMessage()");
				
			}
			
			
			return id;
	}
	@Override
	public ArrayList<StudentBean> retrieveDetails() {
		
		ArrayList<StudentBean> list=new ArrayList<StudentBean>();
		try {
			conn=DbUtil.getConnection();
		
		
		String sql="Select * from Student_score";
		
		
		Statement st=conn.createStatement();
		ResultSet rs=st.executeQuery(sql);
	
		
		while(rs.next())
		{
			int studentId=rs.getInt(1);
			String customerName=rs.getString(2);
			int age=rs.getInt(3);
			String state=rs.getString(4);
			String gender=rs.getString(5);
			int noOfSubject=rs.getInt(6);
			int noOfAttempt=rs.getInt(7);
			int totalNoSubject=rs.getInt(8);
			
			
			
			
			list.add(new StudentBean(studentId,customerName,age,state,gender,noOfSubject,noOfAttempt,totalNoSubject));
			
			
		}
		
		
		}
		catch (SQLException e)
		{
			
			System.out.println(e.getMessage());
		}
		
		return list;
		
	}

}
