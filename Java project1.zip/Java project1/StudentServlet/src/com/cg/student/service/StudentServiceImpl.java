package com.cg.student.service;


import java.util.ArrayList;


import com.cg.student.bean.StudentBean;
import com.cg.student.dao.IStudentDao;
import com.cg.student.dao.StudentDaoImpl;

public class StudentServiceImpl implements IStudentService{
	
	IStudentDao dao=null;
	@Override
	public int insertStudent(StudentBean bean) {
		
		dao=new StudentDaoImpl();
		return dao.insertStudent(bean);
	}
	@Override
	public ArrayList<StudentBean> retrieveDetails() {
		dao=new StudentDaoImpl();
		return dao.retrieveDetails();
	}

}
