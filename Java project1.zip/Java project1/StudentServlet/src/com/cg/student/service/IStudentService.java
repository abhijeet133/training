package com.cg.student.service;

import java.util.ArrayList;

import com.cg.student.bean.StudentBean;

public interface IStudentService 
{
	public int insertStudent(StudentBean bean);
	public ArrayList<StudentBean> retrieveDetails();
}
