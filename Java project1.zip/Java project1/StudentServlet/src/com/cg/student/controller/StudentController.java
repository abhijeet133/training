package com.cg.student.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;




import com.cg.student.bean.StudentBean;
import com.cg.student.service.IStudentService;
import com.cg.student.service.StudentServiceImpl;


@WebServlet("*.obj")
public class StudentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
     StudentBean bean=new StudentBean();
		
		IStudentService service= new StudentServiceImpl();
		
		HttpSession session=request.getSession();
		
		String target=null;
		String path=request.getServletPath();
		switch(path)
		{
		case "/addNewStudent.obj" :
			
			target="NewStudent.jsp";
			break;
			
		case "/details.obj" :
			
			//String custId=request.getParameter("customerId");
		//	int cId=Integer.parseInt(custId);
			String studentName=request.getParameter("studentName");
			
			String age=request.getParameter("age");
			Integer age1=Integer.parseInt(age);
			
			String state=request.getParameter("txtState");
			
			String gender=request.getParameter("gender");
			
			String noOfSubject=request.getParameter("noOfSubject");
			Integer noOfSubject1=Integer.parseInt(noOfSubject);
			
			String noOfAttempt=request.getParameter("noOfAttempt");
			Integer noOfAttempt1=Integer.parseInt(noOfAttempt);
			
			String totalSubject=request.getParameter("totalSubject");
			Integer totalSubject1=Integer.parseInt(totalSubject);
			
			
		//	bean.setCustomerId(cId);
			bean.setStudentName(studentName);
			bean.setAge(age1);
			bean.setState(state);
			bean.setGender(gender);
			bean.setNoOfSubject(noOfSubject1);
			bean.setNoOfAttempt(noOfAttempt1);
			bean.setTotalSubject(totalSubject1);
			
			
			
			int res=service.insertStudent(bean);
			
			if(res==0)
			{
				target="Error.html";
				
				
			}
			else
			{
				
				session.setAttribute("val", res);
				target="success.jsp";
			}
			
			break;
			
		case "/retrieveExistedStudent.obj" :
			

				ArrayList<StudentBean> list=null;
			
				list=service.retrieveDetails();
			
			
				session.setAttribute("list", list);
			
			
				target="StudentScore.jsp";
			
		
			
				
		}
		RequestDispatcher rd=request.getRequestDispatcher(target);
		rd.forward(request, response);
	}
	}

	


