package com.cg.student.bean;

public class StudentBean 
{
	private int studentId;
	private String studentName;
	private int age;
	private String state;
	private String gender;
	private int noOfSubject;
	private int noOfAttempt;
	private int totalSubject;
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getNoOfSubject() {
		return noOfSubject;
	}
	public void setNoOfSubject(int noOfSubject) {
		this.noOfSubject = noOfSubject;
	}
	public int getNoOfAttempt() {
		return noOfAttempt;
	}
	public void setNoOfAttempt(int noOfAttempt) {
		this.noOfAttempt = noOfAttempt;
	}
	public int getTotalSubject() {
		return totalSubject;
	}
	public void setTotalSubject(int totalSubject) {
		this.totalSubject = totalSubject;
	}
	public StudentBean(int studentId, String studentName, int age,
			String state, String gender, int noOfSubject, int noOfAttempt,
			int totalSubject) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.age = age;
		this.state = state;
		this.gender = gender;
		this.noOfSubject = noOfSubject;
		this.noOfAttempt = noOfAttempt;
		this.totalSubject = totalSubject;
	}
	
	
	public StudentBean()
	{
		
	}
	
	
	
	
}
