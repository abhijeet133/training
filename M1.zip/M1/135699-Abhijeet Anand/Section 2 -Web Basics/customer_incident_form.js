function cal(frm)
{
	if(frm.checkValidity()){
		
		var win=window.open("","Customer incident form", "width=300,height=500");
		
		var message= "<html><head><title>Customer incident form</title><style>*{font-Family:'Segoe UI';}</style></head><body></body></html>";
		
		message += "<h2>Name" + frm.txtUN.value+"</h2>";
										//+frm[1].value+"<h2>";
		message += "<h2>Address" + frm.txtAddr.value+"</h2>";
		
		
		message+="<h2>State" + frm.txtState.value+"</h2>";
		message+="<h2>phone" + frm.txtMN.value+"</h2>";
		message+="<h2>E-mail" + frm.txtEmail.value+"</h2>";
		message+="<h2>Preferred way to contact you ? " + frm.contact.value+"</h2>";
		message+="<h2>Date of Visit" + frm.txtDOV.value+"</h2>";
		message+="<h2>Please describe the incident" + frm.txtAddr.value+"</h2>";
		
		
		
		win.document.write(message);
	}
	
}