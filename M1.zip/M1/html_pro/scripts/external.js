// Global variable
var companyName = "Capgemini";
