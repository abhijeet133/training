/*function Interest(p,n,r)
			{
				var res = parseFloat(p.value) * parseInt(n.value) * parseFloat(r.value)/100;
				
				
				//alert('SI is '+cal);
				document.getElementById("res").innerHTML = 'Simple interest is '+res;
			} */
			
function calSI(frm)
{
	if(frm.checkValidity()){
		
		var win=window.open("","Simple interest", "width=300,height=500");
		
		var message= "<html><head><title>Simple interest details..</title><style>*{font-Family:'Segoe UI';}</style></head><body></body></html>";
		
		message += "<h2>Principle Amount is " + frm.txtPRINCIPAL.value+"</h2>";
										//+frm[1].value+"<h2>";
		message += "<h2>no.of years is " + frm.txtTIME.value+"</h2>";
		
		
		message+="<h2>rate of interest is " + frm.txtINTEREST.value+"</h2>";
		
		var p= parseFloat(frm.txtPRINCIPAL.value);
		var n= parseInt(frm.txtTIME.value);
		var r= parseFloat(frm.txtINTEREST.value);
		var si= p * n * r;
		
		message += '<h1>Simple interset is '+si/100+"</h1>";
		
		win.document.write(message);
	}
	
}