CREATE TABLE capgemini_employee(emp_id NUMBER(4) PRIMARY KEY,
                                emp_name VARCHAR(10) NOT NULL,
                                emp_sal NUMBER(7,2) NOT NULL,
                                emp_mobile NUMBER(10) UNIQUE,
                                emp_address VARCHAR2(50) NOT NULL
                                );
SELECT * FROM capgemini_employee;   

INSERT INTO capgemini_employee VALUES(1000,'ABHIJEET',2400,8444992099,'CHENNAI');
INSERT INTO capgemini_employee VALUES(1005,'YAK',2000,8424991025,'PATNA');
INSERT INTO capgemini_employee VALUES(1002,'RAHUL',2402,8444992096,'BANGLORE');
INSERT INTO capgemini_employee VALUES(1008,'HUL',2400,8344992096,'BANGLORE');
INSERT INTO capgemini_employee VALUES(1003,'SAITAN',3600,8444992092,'KOLKATA');
INSERT INTO capgemini_employee VALUES(1004,'PAWAN',8500,8444992091,'HYDRABAD');
INSERT INTO capgemini_employee VALUES(1005,'ANAND',2500,8443992091,'HYDRABAD'),
                                     (1006,'XYZ',2900,7443992091,'MUMBAI'),
                                     (1007,'ABC',4500,5443992091,'PUNE');
UPDATE capgemini_employee SET emp_name='SAYANTANI' WHERE emp_id=1003;
UPDATE capgemini_employee SET emp_SAL= emp_sal+1000 WHERE emp_id=1003;



DELETE capgemini_employee WHERE  emp_id=1000;

ALTER TABLE capgemini_employee ADD emp_location VARCHAR2(10);
ALTER TABLE capgemini_employee MODIFY emp_location VARCHAR2(20);

ALTER TABLE capgemini_employee DROP COLUMN emp_location;

ALTER TABLE capgemini_employee ALTER emp_address VARCHAR(20);
ALTER TABLE capgemini_employee RENAME COLUMN emp_address TO address;

SELECT * FROM capgemini_employee; 

SELECT emp_id,emp_name FROM capgemini_employee ORDER BY emp_name ASC;

SELECT emp_name, emp_sal from capgemini_employee WHERE emp_sal = (SELECT MAX(emp_sal) from capgemini_employee);
SELECT * FROM capgemini_employee;

SELECT emp_name,emp_sal FROM capgemini_employee WHERE emp_sal=(SELECT MAX(emp_sal) FROM capgemini_employee WHERE 
                            emp_sal NOT IN ( SELECT MAX(emp_sal) from capgemini_employee)
                            );
                            
SELECT emp_name FROM capgemini_employee WHERE emp_name LIKE 'V%Y%';      
SELECT SUM(emp_sal) FROM capgemini_employee WHERE emp_address='PATNA';
SELECT SUM(emp_sal) FROM capgemini_employee HAVING count(emp_address)=2 GROUP BY emp_address;

CREATE TABLE department(emp_id NUMBER(5), dept_id NUMBER(5),dept_name VARCHAR2(20),
                        FOREIGN KEY (emp_id) REFERENCES capgemini_employee(emp_id) 
                         );
SELECT * FROM department;
SELECT * FROM capgemini_employee;

INSERT INTO department VALUES(1005,100,'IT');

INSERT INTO department VALUES(1001,101,'CSE');

INSERT INTO department VALUES(1002,102,'ECE');

INSERT INTO department VALUES(1003,103,'AIEE');

SELECT c.emp_name,d.dept_name FROM department d, capgemini_employee c WHERE
       c.emp_id= d.emp_id;
       
CREATE SEQUENCE emp_id_2 START WITH 1005 INCREMENT BY 2;  
CREATE SEQUENCE dept_id START WITH 105 INCREMENT BY 2;
INSERT INTO department VALUES(emp_id_2.nextval,108,'CE'); 

CREATE SEQUENCE emp_id START WITH 1008 INCREMENT BY 2;  
CREATE SEQUENCE dept_id START WITH 105 INCREMENT BY 2;



INSERT INTO department VALUES(emp_id.nextval, dept_id.nextval ,'ECE'); 

SELECT emp_id.currval from dual;
SELECT * FROM department;

CREATE INDEX dept_index ON DEPARTMENT(dept_id);
CREATE VIEW dept_view1 AS SELECT emp_id,dept_id FROM department where dept_id>103;
SELECT * FROM dept_view;
SELECT * FROM dept_view1;

CREATE TABLE HELLO AS SELECT * FROM capgemini_employee;
SELECT * FROM hello;

SET SERVEROUTPUT ON;
DECLARE
 e_name VARCHAR(20);
BEGIN
 SELECT emp_name INTO e_name FROM capgemini_employee WHERE emp_id=1005;
 DBMS_OUTPUT.PUT_LINE('EMPLOYEE NAME ' || e_name);
END;
/