package inheritance1;

 class vehicle {
	
	String color="blue";
	
	void brake()
	{
		
		System.out.println("Super class method");
	}
}
	class car extends vehicle
	{
		String color="red";
		void gear()
		{
			System.out.println(color);
			System.out.println(super.color);
			System.out.println("Sub class method");
			
		}
		
	}
	public	class Main
		{
			
			public static void main(String[] args) {
				
			car c= new car();
			c.gear();
			c.brake();
			
				
			System.out.println(c instanceof car);
			System.out.println(c instanceof vehicle);
			
			}
		}
 
