package lab3;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class DatetimeAssing1 {

	public static void main(String[] args) {
		
		
		Scanner sc= new Scanner(System.in);
		 
		 System.out.println("Enter latest date (dd/mm/yyyy):");
		String cin = sc.nextLine();
		 System.out.println("Enter back date (dd/mm/yyyy):");
			String cin1 = sc.nextLine();
			
		DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		
		LocalDate d1 = LocalDate.parse(cin, f);
		LocalDate d2 = LocalDate.parse(cin1, f);
		
		System.out.println(d1);
		System.out.println(d2);
			
			calculate1 c= new calculate1();
			c.Method(d1, d2);
			
		

	}

}

class calculate1
{
	void Method(LocalDate d1,LocalDate d2)
	{
		System.out.println("Number of years:- "+d2.until(d1, ChronoUnit.YEARS));
		System.out.println("Number of months:- "+d2.until(d1, ChronoUnit.MONTHS));
		System.out.println("Number of days:- "+d2.until(d1, ChronoUnit.DAYS));	
		
	}
}
