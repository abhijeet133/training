package lab3;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class DatetimeAssing {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		
		 LocalDate d= LocalDate.now();
		 
		 System.out.println("Enter date (dd/mm/yyyy):");
		String cin = sc.nextLine();
		
		DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate d1 = LocalDate.parse(cin, f);
		
		calculate c=new calculate();
		c.MethodCal(d,d1);		
	}}
class calculate{
	
	void MethodCal(LocalDate d,LocalDate d1){
		
		System.out.println("Number of years:- "+d1.until(d, ChronoUnit.YEARS));
		System.out.println("Number of months:- "+d1.until(d, ChronoUnit.MONTHS));
		System.out.println("Number of days:- "+d1.until(d, ChronoUnit.DAYS));	
		
	}
}


