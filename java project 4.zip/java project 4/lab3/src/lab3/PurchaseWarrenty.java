/*3.5: Create a method to accept product purchase date and warrantee period 
(in terms of months and years).Print the date on which warrantee of product expires.*/
package lab3;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class PurchaseWarrenty {

	public static void main(String[] args) 
	{
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter Product purchase date(dd/mm/yyyy):- ");
		String product_purchase=sc.nextLine();
		
		System.out.println("Enter warrantee periods(mm/yyyy) :- ");
		String warrenty=sc.nextLine();
			
		calWarrenty c= new calWarrenty();
		c.warrentyCal(product_purchase,warrenty);
		
		
	}

}

class calWarrenty{
	
	void warrentyCal(String product_purchase,String warrenty)
	{
		
      DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy");
   	
		LocalDate d1 = LocalDate.parse(product_purchase, f);
		int dd=d1.getDayOfMonth();
		String c=String.valueOf(dd);
		
	
		c=c.concat("/");
		c=c.concat(warrenty);
		
		LocalDate d2 = LocalDate.parse(c, f);
		
		System.out.println("warrenty of Product expires on :- "+d1.plusDays(d1.until(d2, ChronoUnit.DAYS)));
		
		
	}
}