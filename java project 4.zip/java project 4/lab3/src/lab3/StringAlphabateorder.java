package lab3;
import java.util.Scanner;

public class StringAlphabateorder {
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string:");
		String s=sc.nextLine();
		
		Alphabet a=new Alphabet();
		boolean z=a.compare(s);
		System.out.println(z);
	}

}

class Alphabet{
	
	boolean compare(String s)
	{
		int x=0;
		for(int i=0;i<s.length()-1;i++)
		{
			
			if (s.charAt(i)>s.charAt(i+1))
			{
				 x=1;
			}		
			
			
		}
		
			if(x==1)
				return false;
			else 
				return true;
			
				
		
	}
	
	
	
}