package lab3;

import java.util.Scanner;


public class StringOperationOnChoice {
	
	public static void main(String[] args) 
	{
		Scanner sc=new Scanner(System.in);
		String s="hello";
		System.out.println("Enter choice of operation");
		int choice=sc.nextInt();
		cal c = new cal();
		c.method(s,choice);
		
	}

}

class cal{
	
void	method(String s,int choice)
	{
	switch(choice)
	{
	case 1:    
				s=s.concat("capgimini");
				System.out.println(s);
		break;
	case 2: String s2="";    
		for (int i=0; i < s.length(); i++){
					if (i % 2 != 0){
          //  s = s.substring(0,i-1) + "#" + s.substring(i, s.length());
						s2 += s.charAt(i);

		                s2 = s2+"#";
					}
					}


					System.out.println(s2);
		break;
	case 3:		StringBuffer b= new StringBuffer(s);
				for (int i=0;i<b.length()-1;i++)
				{
					for (int j=i+1;j<b.length();j++)
					{
						if (b.charAt(i)==b.charAt(j))
							
						
						 b.deleteCharAt(j);
					}
				}
	System.out.println("Removed word: " + b);
		break;
	case 4: //change odd characters to upper case
		//StringBuffer b1= new StringBuffer(s);
		String s1  = "";
		
		for (int i=0; i < s.length(); i++){
			if (i % 2 != 0)
			{
				s1 += s.charAt(i);

            s1 = s1.toUpperCase();

            } 
        }

        System.out.print(s1);
		
		
				
		break;
	default:
		System.out.println("Invalid Input");
	}
	

		
	}
	
	
	
}

