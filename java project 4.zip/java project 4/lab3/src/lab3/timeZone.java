package lab3;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Scanner;
public class timeZone {

	public static void main(String[] args) {
		
		
		Scanner sc= new Scanner(System.in);
		 
		System.out.println("Enter Zone ID (like Europe/Berlin) :- ");
		String s= sc.nextLine();
 
		localDatetime ld=new localDatetime(); //object
		LocalDateTime x=ld.find(s);		
		System.out.println(x);	

	}

}

class localDatetime{
	 
	 LocalDateTime find(String s)
	{
		ZoneId zone1 = ZoneId.of(s);


		  //  LocalTime now1 = LocalTime.now(zone1);
		    LocalDateTime dt = LocalDateTime.now(zone1);

		   // System.out.println(now1);
		    return dt;

	}

}