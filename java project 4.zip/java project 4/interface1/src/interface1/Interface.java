package interface1;

interface Bike
{
	
	void display();
	
	default void disp()
	{
		
		System.out.println("default in bike");
	}
	static void disp1()
	{
		System.out.println("using static");
	}
}

interface Car{
	
	void show();
} 

interface Auto
{
	void call();
}

 class Vehicle implements Bike,Car,Auto{
	 
	 
	public void display()
	{
		
		System.out.println("this is display of bike");
	}
	public void show()
	{
		
		System.out.println("this is show of car");
	}
	public void call()
	{
		
		System.out.println("this is call of auto");
	}
	
	
}
 
 public class Interface{
	 
	 public static void main(String[] args)
	 {
		 
		 Vehicle v = new Vehicle();
		 
			v.display();
			v.show();
			v.call();
			v.disp();
			Bike.disp1();
		 
	 }
 }