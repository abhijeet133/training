package jdbc;

import java.sql.*;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException, SQLException 
	{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection(
				"jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg331","training331");
		/*{
		Statement stmt=con.createStatement();
		
		ResultSet rs=stmt.executeQuery("select * from employee");
		while(rs.next())
		{
			
			System.out.println(rs.getInt(1)+" "+rs.getString(2));
			
		}
		con.close();
		}*/
		
		
		PreparedStatement ps=con.prepareStatement("insert into employee values(?,?)");
		ps.setInt(1, 125);
		ps.setString(2, "vin");
		int r= ps.executeUpdate();
		System.out.println(r+" rows inserted");

	}

}
