package junit1;

import static org.junit.Assert.*;

import org.junit.Test;

public class Test1 {

	@Test
	public void test() {
		Calc Ca = new Calc();
		
		int res=Ca.add(2,4);
		assertEquals(8,res);
		
	}

}
