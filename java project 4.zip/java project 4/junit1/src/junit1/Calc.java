package junit1;

public class Calc {
	
	int add(int a,int b)
	{
		return a+b;
	}

}
