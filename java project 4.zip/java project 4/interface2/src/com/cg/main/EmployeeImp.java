package com.cg.main;



public class EmployeeImp implements IEmployee {

	
	public void display() {
		
		System.out.println("display");
	}

	
	public void insert() {
		System.out.println("insert");
		
	}

	
	public void retrive() {
		
		System.out.println("retrive");
	}
	
	public static void main(String[] args) {
		EmployeeImp e=new EmployeeImp();
		e.display();
		e.insert();
		e.retrive();
		
	}

}
