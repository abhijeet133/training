package com.cg.main;

public interface IEmployee {
	
	
	void display();
	void insert();
	void retrive();

}
