package lab2;
import java.util.Scanner;

public class PersonMain
{
	public static void main(String[] args)
	{
		Person p=new Person();
		
		Scanner sc=new Scanner(System.in);
		
		
		System.out.println("Enter First name:");
		String firstName=sc.next();
		p.setFirstName(firstName);
		
		
		System.out.println("Last name:");
		String lastName=sc.next();
		p.setLastName(lastName);
		
		
		System.out.println("Gender:");
		char gender=sc.next().charAt(0);
		p.setGender(gender);
		
		
		 System.out.println("Person details:"+"\n");
		 System.out.println("_________________"+"\n"+"\n");
		 System.out.println("First Name:"+firstName+"\n");
		 System.out.println("Last Name:"+lastName+"\n");
		 System.out.println("Gender:"+gender+"\n");
		
	}
}
