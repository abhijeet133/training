package jdbcProperty;

import java.io.IOException;
import java.sql.*;

public class Main {

	public static void main(String[] args) throws ClassNotFoundException, SQLException, IOException 
	{
		Connection conn=DBUtil.getConnection();
		
		Statement stmt=conn.createStatement();
		
		ResultSet rs=stmt.executeQuery("select * from employee");
		while(rs.next())
		{
			
			System.out.println(rs.getInt(1)+" "+rs.getString(2));
			
		}
		conn.close();
		
		
		
	/*	PreparedStatement ps=conn.prepareStatement("insert into employee values(?,?)");
		ps.setInt(1, 125);
		ps.setString(2, "vin");
		int r= ps.executeUpdate();
		System.out.println(r+" rows inserted");*/

	}

}
