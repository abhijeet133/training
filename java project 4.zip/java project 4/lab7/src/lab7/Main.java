//7.1: Write a program to store product names in a string array and sort strings available
//in an array.
package lab7;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of array");
		int n=sc.nextInt();
		System.out.println("Enter name of product");
		
		String s[]=new String[n];
		for(int i=0;i<s.length;i++)
		{
			s[i]=sc.nextLine();
		}
		
		Arrays.sort(s);
		for(int i=0;i<s.length;i++)
		{
			System.out.println("After sorted " +s[i]);
		}
		
		
	}	

}
