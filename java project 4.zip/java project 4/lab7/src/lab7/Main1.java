//7.2: Modify the above program to store product names in anArrayList, 
//sort strings available in an arrayList and display the names using for-each loop.

package lab7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main1 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter size of array");
		int n=sc.nextInt();
		System.out.println("Enter name of product");
		
		String s[]=new String[n];
		
		ArrayList<String> al= new ArrayList<String>();
		for(int i=0;i<s.length;i++)
		{
			
			
			
			al.add(sc.next());
			
		}
		System.out.println(al);
		
		
		
	/*	al.add("pen");
		al.add("pencil");
		al.add("book");
		System.out.println(al);*/
		
Collections.sort(al);
for(String a: al)
{
	System.out.println(a);
	
}
		

	}

}
